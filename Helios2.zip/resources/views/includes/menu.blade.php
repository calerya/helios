<div class="card border-primary mb-3" style="max-width: 20rem;">
<div class="card-header">
      <h4>Menú</h4>
</div>
  <div class="card-body">
        
    <div class="list-group">
            
        <a href="#" class="list-group-item list-group-item-action">
        Proyectos
        </a>

        <a href="#" class="list-group-item list-group-item-action">
        Buscar
        </a>

        <a href="#" class="list-group-item list-group-item-action">
        Alta de proyectos
        </a>

        <a href="#" class="list-group-item list-group-item-action">
        Usuarios
        </a>

    </div>
      
      
  </div>
    
</div>


