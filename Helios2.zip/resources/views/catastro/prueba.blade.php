@extends('layouts.app')

@section('content')
<h2>Datos de catastro</h2>
<datos-catastro></datos-catastro>

@endsection