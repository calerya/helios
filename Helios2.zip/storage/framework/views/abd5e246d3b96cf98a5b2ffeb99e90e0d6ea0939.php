<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Helios')); ?></title>

    
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    
    <!-- Iconos -->
    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/flatly/bootstrap.min.css" integrity="sha384-qF/QmIAj5ZaYFAeQcrQ6bfVMAh4zZlrGwTPY7T/M+iTTLJqJBJjwwnsE5Y0mV7QK" crossorigin="anonymous">

   
    
</head>
<body>
    <div id="app">
     <!--   <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm"> -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        
            <div class="container">
                
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                  <img src="<?php echo e(asset('logo.png')); ?>" height="30" alt="Logo">
                </a>
                
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'Helios')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        
                        
                        
                     
                    <?php if(auth()->check()): ?>    
                        <?php if(auth()->user()->rol==4): ?>
                        
                        <li <?php if(request()->is('listado')): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                            <a class="nav-link" href="/listado">Proyectos</a>
                        </li>
                        <li <?php if(request()->is('buscar')): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                            <a class="nav-link" href="/buscar">Buscar</a>
                        </li>
                        <?php endif; ?>
                        
                        
                          
                        <?php if(auth()->user()->rol!=4): ?>
                            <li <?php if(request()->is('proyectos')): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                            <a class="nav-link" href="/proyectos">Proyectos</a>
                          </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->user()->rol!=4): ?>
                            <li <?php if(request()->is('buscador')): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                            <a class="nav-link" href="/buscador">Buscar proyectos</a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->user()->rol!=4): ?>
                            <li <?php if(request()->is('listados')): ?> class="nav-item active" <?php else: ?> class="nav-item" <?php endif; ?>>
                            <a class="nav-link" href="/listados">Listado organismos</a>
                            </li>
                        <?php endif; ?>
                          
                        
                        
                            <?php if(auth()->user()->rol==1): ?>
                                <li <?php if(request()->is('usuarios')): ?> class="nav-item active" 
                                    <?php else: ?> class="nav-item" <?php endif; ?>>
                                    <a class="nav-link" href="/usuarios">Usuarios</a>
                                </li>
                            <?php endif; ?>
                        
                        <?php else: ?>
                          <li class="nav-item">
                            <a class="nav-link" href="#">Bienvenido</a>
                          </li>
                        
                        <?php endif; ?>
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        
        
                
                <div class="col-md-12" style="padding-top: 15px;">
                    
                    
                        <?php echo $__env->yieldContent('content'); ?>
                  
                    
                </div>
                
            </div>
      

    
       
 

   
    
        
    <script
  src="https://code.jquery.com/jquery-3.5.1.min.js"
  integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0="
  crossorigin="anonymous"></script>
    
    
    
    
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>

    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    
     
    <script src="https://kit.fontawesome.com/65c47391df.js" crossorigin="anonymous"></script>
    
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    

    
    <?php echo $__env->yieldContent('scripts'); ?>
    

    
</body>
</html>
<?php /**PATH /home/iqlicedk/Helios/resources/views/layouts/app.blade.php ENDPATH**/ ?>