

<?php $__env->startSection('content'); ?>


   

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
    
            
<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

            <div class="card border-primary mb-3">
                
                <div class="card-header text-md-center">
                    <h5>Recuperar usuarios eliminados</h5>
                </div>
                
            <table class="table table-hover">
               
                <thead>
                    <tr>
                        <th scope="col">Usuario</th>
                        <th scope="col">E-Mail</th>
                        <th scope="col">Tipo usuario</th>
                        <th style="text-align:center;" scope="col">Opciones</th>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <?php if($user->rol==1): ?>
                            <td >Administrador</td>
                        <?php endif; ?>
                        <?php if($user->rol==2): ?>
                            <td >Responsable</td>
                        <?php endif; ?>
                        <?php if($user->rol==3): ?>
                            <td >Usuario/Técnico</td>
                        <?php endif; ?>
                        <?php if($user->rol==4): ?>
                            <td >Sólo consultas</td>
                        <?php endif; ?>
                        
                        
                        <td style="text-align:center;">
                            
                            
                            <a href='/recuperar/<?php echo e($user->id); ?>/usuarios' class="btn btn-sm btn-success" title="Recuperar usuario">
                                <i class="fas fa-user-plus"></i>
                            </a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>
                
                 
        
        </div>
            
            
            
            
            </div>
        </div>
    </div>

                
<?php echo e($users->links()); ?>

  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/helios/resources/views/admin/users/eliminados/usuarios.blade.php ENDPATH**/ ?>