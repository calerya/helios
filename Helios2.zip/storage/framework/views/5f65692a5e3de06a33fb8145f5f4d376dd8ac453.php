<?php $__env->startSection('content'); ?>


   

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            
    
            
<?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

            <div class="card border-primary mb-3">
                
            <form action="" method="post">    
        
                <?php echo e(csrf_field()); ?>

        
                    
                                                                                       
                        <div class="card-header">
                            <h4>Usuarios</h4>
                        </div>

                        <div class="card-body">
                                            
                            <div class="form-group row">
                                <label for="name" class="col-md-2 col-form-label text-md-right">Usuario</label>

                                <div class="col-md-4">
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                </div>
                           
                                <label for="email" class="col-md-2 col-form-label text-md-right">E-mail</label>

                                <div class="col-md-4">
                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email" autofocus>

                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                    
                            <div class="form-group row">
                                <label for="password" class="col-md-2 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-4">
                                    <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            
                                <label for="rol" class="col-md-2 col-form-label text-md-right">Tipo de usuario</label>
                                <div class="col-md-4">
                                    <select name="rol" class="form-control" required>
                                        <option value=1>Administrador</option>
                                        <option value=2>Responsable</option>
                                        <option value=3>Usuario / Técnico</option>
                                        <option value=4>Sólo consultas</option>
                                    </select>
                                </div>
                            </div>
                            
                            
                            
                            <div class="form-group row mb-0">
                                <div class="col-md-4 offset-md-2">
                                <button class="btn btn-primary">Registrar usuario</button>
                                </div>
                            </div>
                        </div>
               
                </form>
            
            
            
            
            <table class="table table-hover">
               
                <thead>
                    <tr>
                        <th scope="col">Usuario</th>
                        <th scope="col">E-Mail</th>
                        <th scope="col">Tipo usuario</th>
                        <th scope="col">Opciones</th>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <?php if($user->rol==1): ?>
                            <td >Administrador</td>
                        <?php endif; ?>
                        <?php if($user->rol==2): ?>
                            <td >Responsable</td>
                        <?php endif; ?>
                        <?php if($user->rol==3): ?>
                            <td >Usuario/Técnico</td>
                        <?php endif; ?>
                        <?php if($user->rol==4): ?>
                            <td >Sólo consultas</td>
                        <?php endif; ?>
                        
                        
                        <td>
                            
                            <a href="/usuario/<?php echo e($user->id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                            <a href="/usuario/<?php echo e($user->id); ?>/eliminar" class="btn btn-sm btn-danger" title="Dar de baja">
                                <i class="fas fa-trash-alt"></i>
                            </a>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>
                
                 
        
        </div>
            
            
            
            
            </div>
        </div>
    </div>

                
<?php echo e($users->links()); ?>

  


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/admin/users/index.blade.php ENDPATH**/ ?>