

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
                
            <form action="" method="post">
                
                <?php echo e(csrf_field()); ?>

        
                                                                                       
                

                        <div class="card-body">
                            <fieldset class="border p-2">
                                <legend class="w-auto">Alta de proyecto</legend>                
                            <div class="form-group row"> 
                                <label for="nom_proyecto" class="col-md-2 col-form-label text-md-center">Proyecto</label>
                                <label for="provincia" class="col-md-2 col-form-label text-md-center">Provincia</label>
                                <label for="term_municipal" class="col-md-2 col-form-label text-md-center">Term. municipal</label>
                                <label for="sociedad" class="col-md-2 col-form-label text-md-center">Sociedad</label>
                                <label for="hitos" class="col-md-2 col-form-label text-md-center">Hitos</label>
                                <label for="opciones" class="col-md-2 col-form-label text-md-center">Opciones</label>
                            </div>

                            <div class="form-group row"> 
                                <div class="col-md-2">
                                    <input id="nom_proyecto" type="text" class="form-control" maxlength="50" title="Tamaño máximo 50 caracteres" name="nom_proyecto" value="<?php echo e(old('nom_proyecto')); ?>" required autocomplete="nom_proyecto" autofocus>
                                </div>
                                
                                <div class="col-md-2">
                                    <select name="provincia" class="form-control" title="Selecciona la provincia del proyecto" value="<?php echo e(old('provincia')); ?>" required autocomplete="provincia">
                                        <option value="">Seleccione provincia</option>
                                        <option value="A Coruña">A Coruña</option>
                                        <option value="Álava">Álava</option>
                                        <option value="Albacete">Albacete</option>
                                        <option value="Alicante">Alicante</option>
                                        <option value="Almería">Almería</option>
                                        <option value="Asturias">Asturias</option>
                                        <option value="Ávila">Ávila</option>
                                        <option value="Barcelona">Barcelona</option>
                                        <option value="Burgos">Burgos</option>
                                        <option value="Cáceres">Cáceres</option>
                                        <option value="Cádiz">Cádiz</option>
                                        <option value="Cantabria">Cantabria</option>
                                        <option value="Castellón">Castellón</option>
                                        <option value="Ciudad Real">Ciudad Real</option>
                                        <option value="Córdoba">Córdoba</option>
                                        <option value="Cuenca">Cuenca</option>
                                        <option value="Girona">Girona</option>
                                        <option value="Granada">Granada</option>
                                        <option value="Guadalajara">Guadalajara</option>
                                        <option value="Guipúzcoa">Guipúzcoa</option>
                                        <option value="Huelva">Huelva</option>
                                        <option value="Huesca">Huesca</option>
                                        <option value="Islas Baleares">Islas Baleares</option>
                                        <option value="Jaén">Jaén</option>
                                        <option value="La Rioja">La Rioja</option>
                                        <option value="Las Palmas">Las Palmas</option>
                                        <option value="León">León</option>
                                        <option value="Lleida">Lleida</option>
                                        <option value="Lugo">Lugo</option>
                                        <option value="Madrid">Madrid</option>
                                        <option value="Málaga">Málaga</option>
                                        <option value="Murcia">Murcia</option>
                                        <option value="Navarra">Navarra</option>
                                        <option value="Ourense">Ourense</option>
                                        <option value="Palencia">Palencia</option>
                                        <option value="Pontevedra">Pontevedra</option>
                                        <option value="Salamanca">Salamanca</option>
                                        <option value="S. C. Tenerife">S. C. Tenerife</option>
                                        <option value="Segovia">Segovia</option>
                                        <option value="Sevilla">Sevilla</option>
                                        <option value="Soria">Soria</option>
                                        <option value="Tarragona">Tarragona</option>
                                        <option value="Teruel">Teruel</option>
                                        <option value="Toledo">Toledo</option>
                                        <option value="Valencia">Valencia</option>
                                        <option value="Valladolid">Valladolid</option>
                                        <option value="Vizcaya">Vizcaya</option>
                                        <option value="Zamora">Zamora</option>
                                        <option value="Zaragoza">Zaragoza</option>
                                        <option value="PD">Por definir</option>
                                    </select>
                                </div>
                                
                                <div class="col-md-2">
                                    <input id="term_municipal" type="text" class="form-control" maxlength="80" title="Tamaño máximo 80 caracteres" name="term_municipal" value="<?php echo e(old('term_municipal')); ?>" required autocomplete="term_municipal">
                                </div>
                                <div class="col-md-2">
                                    <input id="sociedad" type="text" class="form-control" maxlength="80" title="Tamaño máximo 80 caracteres"name="sociedad" value="<?php echo e(old('sociedad')); ?>" required autocomplete="sociedad">
                                </div>
                                
                                
                                <div class="col-md-2">
                                    <select name="hitos" class="form-control" title="Selecciona los hitos completados del proyecto" value="<?php echo e(old('hitos')); ?>" required autocomplete="hitos">
                                        <option value="">Seleccione hitos completados</option>
                                        <option value="0" selected>0 hitos</option>
                                        <option value="1">1 hito</option>
                                        <option value="2">2 hitos</option>
                                        <option value="3">3 hitos</option>
                                        <option value="4">4 hitos</option>
                                        <option value="5">5 hitos</option>
                                    </select>
                                </div>
                            
                                
                                
                                
                                
                                <div class="col-md-2 text-md-center">
                                
                                <button class="btn btn-primary" title="Alta de Proyecto"><i class="fas fa-save"></i></button>
                           
                                <button type="reset" class="btn btn-danger" title="Limpiar campos"><i class="fas fa-times"></i></button>
                                
                                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary" title="Volver atrás sin guardar datos">
                                <i class="fas fa-reply"></i>
                                </a>
                                
                                </div>
                                
                                
                            </div>
                              </fieldset>   
                          
                        </div>
                      
               
                </form>
            
        
             
            <div class="col-md-12">
                <div class="table-responsive">
          
                 <table class="table table-hover table-bordered" style="text-align:center;">
               
                <thead>
                    <tr class="table-primary">
                        <div><th width="20%" scope="col">Nombre</th></div>
                        <div><th width="10%" scope="col">Provincia</th></div>
                        <div><th  width="20%"scope="col">Término municipal</th></div>
                        <div><th width="17%" scope="col">Sociedad</th></div>
                        <div><th width="6%" scope="col">Alta</th></div>
                        <div><th width="6%" scope="col">Hitos</th></div>
                        <div><th width="6%" scope="col">Tot / Fin</th></div>
                        <div><th width="15%" scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div><td width="20%"><a href="/proyecto/<?php echo e($proyecto->id); ?>/ver"><?php echo e($proyecto->nom_proyecto); ?></a></td></div>
                        <div><td width="10%"><?php echo e($proyecto->provincia); ?></td></div>
                        <div><td width="20%"><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div><td width="17%"><?php echo e($proyecto->sociedad); ?></td></div>
                        <div><td width="6%"><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td></div>
                        
                        <!--
                        <div><td width="6%"><?php echo e($proyecto->hitos); ?></td></div>
                        -->
                        
                        <div><td width="6%"><a href="/hitos/<?php echo e($proyecto->id); ?>/ver">Ver hitos</a></td></div>
                        
                        <div><td width="6%"><?php echo e($proyecto->tot); ?> / <?php echo e($proyecto->fin); ?></td></div>
                        <div><td width="15%">
                            
                        
                            
                            <!--
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/ver" class="btn btn-sm btn-primary" title="Ver">
                                <i class="far fa-eye"></i>
                            </a> -->
                            
                                                        
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/excel" class="btn btn-sm btn-primary" title="Descargar EXCEL del proyecto"><i class="fas fa-file-excel"></i></a>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                            <a href="/organismo/<?php echo e($proyecto->id); ?>/ver" class="btn btn-sm btn-primary" title="Añadir organismo" 
                                id="boton-alta-org" ><i class="fas fa-plus-square"></i>
                            </a>
                            
                             <?php if(($proyecto->tot>0)and($proyecto->tot==$proyecto->fin)): ?>
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/finalizar" class="btn btn-sm btn-success" title="Dar por finalizado el proyecto">
                                <i class="fas fa-flag-checkered"></i>
                            </a>
                            <?php endif; ?>
                            
                            
                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal" title="Eliminar el proyecto"><i class="fas fa-trash-alt"></i></button>
                            
                            <div class="modal" id="exampleModal">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title">Eliminar proyecto</h5>
                                      
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                    <div class="text-center">
                                        <span class="text-warning"><i style="font-size:70px" class="fas fa-exclamation-circle"></i></span>  
                                    </div>
                                    <p>Quiere eliminar el proyecto <?php echo e($proyecto->nom_proyecto); ?> y sus organismos?</p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                      <a href="/proyecto/<?php echo e($proyecto->id); ?>/eliminar"><button class="btn btn-danger">Eliminar</button></a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            
                                                      
            
                        </td></div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>  
        </div>  
        </div>
                        
                    
                </div>
                    
     <?php echo e($proyectos->links()); ?>


<?php $__env->stopSection(); ?>


  


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/proyectos/index.blade.php ENDPATH**/ ?>