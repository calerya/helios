

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('busqueda')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('busqueda')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    

      

    
    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-12">
             <legend class="w-auto">Listado de proyectos</legend>   
            
             
               
             <div class="col-md-12">
                <div class="table-responsive">
          
                
                    <table class="table table-bordered yajra-datatable">
                <thead>
                    <tr>
                        <div><th width="20%" scope="col">Nombre</th></div>
                        <div><th width="12%" scope="col">Provincia</th></div>
                        <div><th width="16%"scope="col">Término municipal</th></div>
                        <div><th width="14%" scope="col">Sociedad</th></div>
                        <div><th width="9%" scope="col">Técnico</th></div>
                        <div><th width="9%" scope="col">Alta</th></div>
                        <div><th width="4%" scope="col"><a class="btn btn-primary btn-sm" title="Organismos">
                            <i class="fas fa-university"></i></a></th></div>
                        <div><th width="4%" scope="col"><a class="btn btn-primary btn-sm" title="Fincas">
                            <i class="fas fa-map-marked-alt"></i>
                            </a></th></div>
                        <div><th width="12%" scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    
                
                </tbody>
                 
            </table>
            </div>
            </div>
                  
        </fieldset>    
        
    
</div>

            
   
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>



<script type="text/javascript">

    $(function () {
        var table = $('.yajra-datatable').DataTable({
          processing: true,
          serverSide: true,
          ajax: "<?php echo e(route('buscar.proyectos')); ?>",
          columns: [
              {data: 'nom_proyecto', name: 'nom_proyecto'},
              {data: 'provincia', name: 'provincia'},
              {data: 'term_municipal', name: 'term_municipal'},
              {data: 'sociedad', name: 'sociedad'},
              {data: 'usu', name: 'usu'},
              {data: 'created_at', name: 'created_at'},
              {data: 'tot', name: 'tot'},
              {data: 'fin', name: 'fin'},
              {
                  data: 'action', 
                  name: 'action', 
                  orderable: false, 
                  searchable: false
              },
          ],
          columnDefs: [ 
              {'targets': [5,6,7], // column index (start from 0)
               'orderable': false, // set orderable false for selected columns
               'searchable': false,
               //'className': 'text-center',
              },
               {
                'targets': [5,6,7,8],
                'className': 'text-center ',
               
              },
             
          ],
      });
      
    });
  </script>
  
<?php $__env->stopSection(); ?> 
  


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/proyectos/buscador.blade.php ENDPATH**/ ?>