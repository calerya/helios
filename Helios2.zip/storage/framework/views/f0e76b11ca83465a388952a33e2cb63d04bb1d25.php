<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>



    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>


        <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header" style="text-align-center">
                    <h4>Info del proyecto <?php echo e($proyecto->nom_proyecto); ?> - Seleccione organismo en el desplegable.</h4>
                </div>
                

                <div class="card-body">
                    
                    <select name="proyecto-id" id="proyecto-id" style="visibility:hidden">
                        <option value=" <?php echo e($proyecto->id); ?> " selected> <?php echo e($proyecto->id); ?> </option>
                    
                    </select>
                    
                    <table class="table table-hover" style="text-align:center;">
               
                        <thead>
                            <tr class="table-primary">
                                <th scope="col">Nombre del proyecto</th>
                                <th scope="col">Provincia</th>
                                <th scope="col">Term. Municipal</th>
                                <th scope="col">Nº expedientes</th>
                                <th scope="col">Organismo</th>
                                <th scope="col">Opciones</th>
                            </tr>
                        </thead>               
                        
                        <tbody>
                  
                            <tr>
                                <td><?php echo e($proyecto->nom_proyecto); ?></td>
                                <td><?php echo e($proyecto->provincia); ?></td>
                                <td><?php echo e($proyecto->term_municipal); ?></td>
                                <td><?php echo e($organismos->count()); ?></td>
                                <td>
                                            <select id="select-organismo" name="select-organismo">
                                                <option value="-1" selected>Selecciona organismo</option>
                                                <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option value=" <?php echo e($org->id); ?> "> <?php echo e($org->organismo); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            

                                    
                                </td>
                                <td>
                                    <div>
                                         
                                        <div class="btn btn-sm btn-primary" title="Editar organismo/expediente" id="boton-editar-org" style="display:none">
                                            <i class="far fa-edit" ></i>
                                        </div>

                                        <div class="btn btn-sm btn-primary" title="Añadir organismo" 
                                        id="boton-alta-org">
                                            <i class="fas fa-plus-square"></i>
                                        </div>
                                        
                                        <div class="btn btn-sm btn-primary" id="boton-finalizar-org" title="Dar el organismo/expediente por finalizado" style="display:none">
                                            <i class="fas fa-flag-checkered"></i>
                                        </div>
                                        
                                        <div class="btn btn-sm btn-danger" id="boton-eliminar-org" title="Dar de baja organismo/expediente" style="display:none">
                                            <i class="fas fa-trash-alt"></i>
                                        </div>
                                        
                                        <a href="<?php echo e(URL::previous()); ?>" class="btn btn-sm btn-primary" title="Volver atrás sin guardar datos">
                                        <i class="fas fa-reply"></i>
                                        </a>
                                   
                                    </div>
                                </td>
                            </tr>
                                                                                       
                        </tbody>   
                            
                    </table>
            </div>
    </div>
                    
            <div class="card border-primary mb-3">
                                                                                       
                <div class="card-body">
                    
                    <table class="table table-hover" style="text-align:center;">
                        <tr>
                            <th scope="col">Expediente</th>
                            <th scope="col">Presentación</th>
                            <th scope="col">Requerimiento</th>
                            <th scope="col">Cont. Requerimiento</th>
                            <th scope="col">Inf. pública</th>
                            <th scope="col">Fin inf. pública</th>
                        </tr>
                        <tr>
                            <td><div id="num-expediente">-</div></td>
                            <td><div id="fec-presentacion">-</div></td>
                            <td><div id="fec-requerimiento">-</div></td>
                            <td><div id="fec-cont-requerimiento">-</div></td>
                            <td><div id="fec-inicio-ip">-</div></td>
                            <td><div id="fec-fin-ip">-</div></td>
                        </tr>
                        <tr>
                            <th scope="col">Resolución</th>
                            <th scope="col">Publicación res.</th>
                            <th scope="col">Caducidad</th>
                            <th scope="col">Solicitud prórroga</th>
                            <th scope="col">Concesión prórroga</th>
                            <th scope="col">Nº prórrogas</th>
                        </tr>
                        <tr>
                            <td><div id="fec-resolucion">-</div></td>
                            <td><div id="fec-publ-resolucion">-</div></td>
                            <td><div id="fec-caducidad">-</div></td>
                            <td><div id="fec-solic-prorroga">-</div></td>
                            <td><div id="fec-concesion-pror">-</div></td>
                            <td><div id="num-prorrogas">-</div></td>
                        </tr>
            </table>
                  
                    
                 
                  <div class="row">
                    <div class="col-md-2" style="text-align:center;"><strong>Observaciones: </strong></div>
                    <div class="col-md-10" style="text-align:left;" id="observaciones">-</div>
                 </div>     
          
             </div>
                       
          </div>
                    
                    
        

                        
     

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/ver.js"></script>
    

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iqlicedk/Helios/resources/views/proyectos/ver.blade.php ENDPATH**/ ?>