

<?php $__env->startSection('content'); ?>

   <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
                
            <form action="" method="post">    
        
                <?php echo e(csrf_field()); ?>

        
                                                                                       
                <div class="card-header text-md-center">
                    <h4>Editar Proyecto</h4>
                </div>

                        <div class="card-body">
                            
                            <table class="table table-hover" style="text-align:center;">
               
                                <thead>
                                    <tr class="table-primary">
                                        <th scope="col">Proyecto</th>
                                        <th scope="col">Provincia</th>
                                        <th scope="col">Término municipal</th>
                                        <th scope="col">Sociedad</th>
                                <!--        <th scope="col">Hitos</th> -->
                                        <th scope="col">Dado de alta</th>
                                        <th scope="col">Opciones</th>
                                    </tr>
                                </thead>


                                <tbody>
                                                    
                                <tr>
                                    <td><input title="Escribe para cambiar el nombre del proyecto" id="nom_proyecto" type="text" class="form-control text-md-center" maxlength="50" title="Tamaño máximo 50 caracteres" name="nom_proyecto" value="<?php echo e(old('nom_proyecto', $proyecto->nom_proyecto)); ?>" required autocomplete="nom_proyecto" autofocus>
                                    </td>
                              
                                    <td>
                                    <select name="provincia" class="form-control text-md-center" 
                                    value="<?php echo e(old('provincia', $proyecto->provincia)); ?>" required>
                                        
                                        <?php if(($proyecto->provincia) == 'A Coruña'): ?>
                                            <option value="A Coruña" selected>A Coruña</option>
                                        <?php else: ?>
                                            <option value="A Coruña">A Coruña</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Álava'): ?>
                                            <option value="Álava" selected>Álava</option>
                                        <?php else: ?>
                                            <option value="Álava">Álava</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Albacete'): ?>
                                            <option value="Albacete" selected>Albacete</option>
                                        <?php else: ?>
                                            <option value="Albacete">Albacete</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Alicante'): ?>
                                            <option value="Alicante" selected>Alicante</option>
                                        <?php else: ?>
                                            <option value="Alicante">Alicante</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Almería'): ?>
                                            <option value="Almería" selected>Almería</option>
                                        <?php else: ?>
                                            <option value="Almería">Almería</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Asturias'): ?>
                                            <option value="Asturias" selected>Asturias</option>
                                        <?php else: ?>
                                            <option value="Asturias">Asturias</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Ávila'): ?>
                                            <option value="Ávila" selected>Ávila</option>
                                        <?php else: ?>
                                            <option value="Ávila">Ávila</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Barcelona'): ?>
                                            <option value="Barcelona" selected>Barcelona</option>
                                        <?php else: ?>
                                            <option value="Barcelona">Barcelona</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Burgos'): ?>
                                            <option value="Burgos" selected>Burgos</option>
                                        <?php else: ?>
                                            <option value="Burgos">Burgos</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Cáceres'): ?>
                                            <option value="Cáceres" selected>Cáceres</option>
                                        <?php else: ?>
                                            <option value="Cáceres">Cáceres</option>
                                        <?php endif; ?>
                                    
                                        <?php if(($proyecto->provincia) == 'Cádiz'): ?>
                                            <option value="Cádiz" selected>Cádiz</option>
                                        <?php else: ?>
                                            <option value="Cádiz">Cádiz</option>
                                        <?php endif; ?>
                                     
                                        <?php if(($proyecto->provincia) == 'Cantabria'): ?>
                                            <option value="Cantabria" selected>Cantabria</option>
                                        <?php else: ?>
                                            <option value="Cantabria">Cantabria</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Castellón'): ?>
                                            <option value="Castellón" selected>Castellón</option>
                                        <?php else: ?>
                                            <option value="Castellón">Castellón</option>
                                        <?php endif; ?>
                                       
                                        <?php if(($proyecto->provincia) == 'Ciudad Real'): ?>
                                            <option value="Ciudad Real" selected>Ciudad Real</option>
                                        <?php else: ?>
                                            <option value="Ciudad Real">Ciudad Real</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Córdoba'): ?>
                                            <option value="Córdoba" selected>Córdoba</option>
                                        <?php else: ?>
                                            <option value="Córdoba">Córdoba</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Cuenca'): ?>
                                            <option value="Cuenca" selected>Cuenca</option>
                                        <?php else: ?>
                                            <option value="Cuenca">Cuenca</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Girona'): ?>
                                            <option value="Girona" selected>Girona</option>
                                        <?php else: ?>
                                            <option value="Girona">Girona</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Granada'): ?>
                                            <option value="Granada" selected>Granada</option>
                                        <?php else: ?>
                                            <option value="Granada">Granada</option>
                                        <?php endif; ?>
                                       
                                        <?php if(($proyecto->provincia) == 'Guadalajara'): ?>
                                            <option value="Guadalajara" selected>Guadalajara</option>
                                        <?php else: ?>
                                            <option value="Guadalajara">Guadalajara</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Guipúzcoa'): ?>
                                            <option value="Guipúzcoa" selected>Guipúzcoa</option>
                                        <?php else: ?>
                                            <option value="Guipúzcoa">Guipúzcoa</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Huelva'): ?>
                                            <option value="Huelva" selected>Huelva</option>
                                        <?php else: ?>
                                            <option value="Huelva">Huelva</option>
                                        <?php endif; ?>
                                   
                                        <?php if(($proyecto->provincia) == 'Huesca'): ?>
                                            <option value="Huesca" selected>Huesca</option>
                                        <?php else: ?>
                                            <option value="Huesca">Huesca</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Islas Baleares'): ?>
                                            <option value="Islas Baleares" selected>Islas Baleares</option>
                                        <?php else: ?>
                                            <option value="Islas Baleares">Islas Baleares</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Jaén'): ?>
                                            <option value="Jaén" selected>Jaén</option>
                                        <?php else: ?>
                                            <option value="Jaén">Jaén</option>
                                        <?php endif; ?>
                                    
                                        <?php if(($proyecto->provincia) == 'La Rioja'): ?>
                                            <option value="La Rioja" selected>La Rioja</option>
                                        <?php else: ?>
                                            <option value="La Rioja">La Rioja</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Las Palmas'): ?>
                                            <option value="Las Palmas" selected>Las Palmas</option>
                                        <?php else: ?>
                                            <option value="Las Palmas">Las Palmas</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'León'): ?>
                                            <option value="León" selected>León</option>
                                        <?php else: ?>
                                            <option value="León">León</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Lleida'): ?>
                                            <option value="Lleida" selected>Lleida</option>
                                        <?php else: ?>
                                            <option value="Lleida">Lleida</option>
                                        <?php endif; ?>
                                    
                                        <?php if(($proyecto->provincia) == 'Lugo'): ?>
                                            <option value="Lugo" selected>Lugo</option>
                                        <?php else: ?>
                                            <option value="Lugo">Lugo</option>
                                        <?php endif; ?>
                                       
                                        <?php if(($proyecto->provincia) == 'Madrid'): ?>
                                            <option value="Madrid" selected>Madrid</option>
                                        <?php else: ?>
                                            <option value="Madrid">Madrid</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Málaga'): ?>
                                            <option value="Málaga" selected>Málaga</option>
                                        <?php else: ?>
                                            <option value="Málaga">Málaga</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Murcia'): ?>
                                            <option value="Murcia" selected>Murcia</option>
                                        <?php else: ?>
                                            <option value="Murcia">Murcia</option>
                                        <?php endif; ?>
                                       
                                        <?php if(($proyecto->provincia) == 'Navarra'): ?>
                                            <option value="Navarra" selected>Navarra</option>
                                        <?php else: ?>
                                            <option value="Navarra">Navarra</option>
                                        <?php endif; ?>
                                    
                                        <?php if(($proyecto->provincia) == 'Ourense'): ?>
                                            <option value="Ourense" selected>Ourense</option>
                                        <?php else: ?>
                                            <option value="Ourense">Ourense</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Palencia'): ?>
                                            <option value="Palencia" selected>Palencia</option>
                                        <?php else: ?>
                                            <option value="Palencia">Palencia</option>
                                        <?php endif; ?>
                                       
                                        <?php if(($proyecto->provincia) == 'Pontevedra'): ?>
                                            <option value="Pontevedra" selected>Pontevedra</option>
                                        <?php else: ?>
                                            <option value="Pontevedra">Pontevedra</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Salamanca'): ?>
                                            <option value="Salamanca" selected>Salamanca</option>
                                        <?php else: ?>
                                            <option value="Salamanca">Salamanca</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'S. C. Tenerife'): ?>
                                            <option value="S. C. Tenerife" selected>S. C. Tenerife</option>
                                        <?php else: ?>
                                            <option value="S. C. Tenerife">S. C. Tenerife</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Segovia'): ?>
                                            <option value="Segovia" selected>Segovia</option>
                                        <?php else: ?>
                                            <option value="Segovia">Segovia</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Sevilla'): ?>
                                            <option value="Sevilla" selected>Sevilla</option>
                                        <?php else: ?>
                                            <option value="Sevilla">Sevilla</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Soria'): ?>
                                            <option value="Soria" selected>Soria</option>
                                        <?php else: ?>
                                            <option value="Soria">Soria</option>
                                        <?php endif; ?>
                                    
                                        <?php if(($proyecto->provincia) == 'Tarragona'): ?>
                                            <option value="Tarragona" selected>Tarragona</option>
                                        <?php else: ?>
                                            <option value="Tarragona">Tarragona</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Teruel'): ?>
                                            <option value="Teruel" selected>Teruel</option>
                                        <?php else: ?>
                                            <option value="Teruel">Teruel</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Toledo'): ?>
                                            <option value="Toledo" selected>Toledo</option>
                                        <?php else: ?>
                                            <option value="Toledo">Toledo</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Valencia'): ?>
                                            <option value="Valencia" selected>Valencia</option>
                                        <?php else: ?>
                                            <option value="Valencia">Valencia</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Valladolid'): ?>
                                            <option value="Valladolid" selected>Valladolid</option>
                                        <?php else: ?>
                                            <option value="Valladolid">Valladolid</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Vizcaya'): ?>
                                            <option value="Vizcaya" selected>Vizcaya</option>
                                        <?php else: ?>
                                            <option value="Vizcaya">Vizcaya</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Zamora'): ?>
                                            <option value="Zamora" selected>Zamora</option>
                                        <?php else: ?>
                                            <option value="Zamora">Zamora</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Zaragoza'): ?>
                                            <option value="Zaragoza" selected>Zaragoza</option>
                                        <?php else: ?>
                                            <option value="Zaragoza">Zaragoza</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->provincia) == 'Por definir'): ?>
                                            <option value="Por definir" selected>Por definir</option>
                                        <?php else: ?>
                                            <option value="Por definir">Por definir</option>
                                        <?php endif; ?>
                                        
                                    </select>
                                </td>
                                
                                <td>
                                    <input id="term_municipal" type="text" class="form-control text-md-center" maxlength="80" title="Tamaño máximo 80 caracteres" name="term_municipal" value="<?php echo e(old('term_municipal', $proyecto->term_municipal)); ?>" required autocomplete="term_municipal">
                                </td>
                                
                                <td>
                                    <input id="sociedad" type="text" class="form-control text-md-center" maxlength="80" title="Tamaño máximo 80 caracteres"name="sociedad" value="<?php echo e(old('sociedad', $proyecto->sociedad)); ?>" required autocomplete="sociedad">
                                </td>
                                    
                         <!--       <td>
                                    <select name="hitos" class="form-control text-md-center" 
                                    value="<?php echo e(old('hitos', $proyecto->hitos)); ?>" required>
                                        
                                        <?php if(($proyecto->hitos) == '0'): ?>
                                            <option value="0" selected>0 hitos</option>
                                        <?php else: ?>
                                            <option value="0">0 hitos</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->hitos) == '1'): ?>
                                            <option value="1" selected>1 hito</option>
                                        <?php else: ?>
                                            <option value="1">1 hito</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->hitos) == '2'): ?>
                                            <option value="2" selected>2 hitos</option>
                                        <?php else: ?>
                                            <option value="2">2 hitos</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->hitos) == '3'): ?>
                                            <option value="3" selected>3 hitos</option>
                                        <?php else: ?>
                                            <option value="3">3 hitos</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->hitos) == '4'): ?>
                                            <option value="4" selected>4 hitos</option>
                                        <?php else: ?>
                                            <option value="4">4 hitos</option>
                                        <?php endif; ?>
                                        
                                        <?php if(($proyecto->hitos) == '5'): ?>
                                            <option value="5" selected>5 hitos</option>
                                        <?php else: ?>
                                            <option value="5">5 hitos</option>
                                        <?php endif; ?>
                                    
                                    </select>
                                </td> -->
                                        
                                        
                                <td>
                                    <input title="La fecha de alta no se puede modificar" id="created_at" type="text" class="form-control text-md-center" name="created_at" value="<?php echo e(old('created_at', $proyecto->created_at->format('d/m/Y'))); ?>" disabled>
                                </td>
                                                                
                                
                                    
                                <td class="text-md-center">
                                    
                                    <button class="btn btn-primary" title="Guardar proyecto"><i class="fas fa-save"></i></button>

                                    <button type="reset" class="btn btn-danger" title="Cancelar edición"><i class="fas fa-times"></i></button>

                                    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary" title="Volver atrás sin guardar datos">
                                    <i class="fas fa-reply"></i>
                                    </a>
                              
                                </td>
                                
                          
                            </tbody>
                        </table>
                </div>
            </form>
            
        
                        
                    
    </div>
                    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/proyectos/edit.blade.php ENDPATH**/ ?>