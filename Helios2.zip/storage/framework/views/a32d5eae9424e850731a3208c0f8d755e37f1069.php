

<?php $__env->startSection('content'); ?>
<h2>Datos de catastro</h2>
<datos-catastro></datos-catastro>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/catastro/prueba.blade.php ENDPATH**/ ?>