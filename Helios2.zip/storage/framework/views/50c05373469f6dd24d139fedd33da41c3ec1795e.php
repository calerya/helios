

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    
    <div class="card border-primary col-md-6 mb-3 mx-auto">
                
        <form action="" method="post" novalidate>
            <?php echo e(csrf_field()); ?>

        
               <div class="card-body">
                    <fieldset class="border p-2">
                        <legend class="w-auto">Alta de proyecto</legend>
                                              

                          
                            <div class="form-group col-md-8 mx-auto">
                                <label for="nom_proyecto" class="col-form-label text-md-center">Nombre del proyecto</label>
                                <input id="nom_proyecto" type="text" class="form-control <?php $__errorArgs = ['nom_proyecto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" title="Tamaño máximo 50 caracteres" name="nom_proyecto" value="<?php echo e(old('nom_proyecto')); ?>" autocomplete="nom_proyecto" autofocus>
                                <?php $__errorArgs = ['nom_proyecto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                                
                                
                            <div class="form-group col-md-8 mx-auto">
                                <label for="provincia" class="col-form-label text-md-center">Provincia</label>
                                <select name="provincia" class="form-control <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" title="Selecciona la provincia del proyecto" value="<?php echo e(old('provincia')); ?>" autocomplete="provincia">
                                        <option disabled selected>Seleccione provincia</option>
                                        <option value="A Coruña" <?php echo e(old('provincia') == "A Coruña" ? 'selected' : ''); ?>>A Coruña</option>
                                        <option value="Álava" <?php echo e(old('provincia') == "Álava" ? 'selected' : ''); ?>>Álava</option>
                                        <option value="Albacete" <?php echo e(old('provincia') == "Albacete" ? 'selected' : ''); ?>>Albacete</option>
                                        <option value="Alicante" <?php echo e(old('provincia') == "Alicante" ? 'selected' : ''); ?>>Alicante</option>
                                        <option value="Almería" <?php echo e(old('provincia') == "Almería" ? 'selected' : ''); ?>>Almería</option>
                                        <option value="Asturias" <?php echo e(old('provincia') == "Asturias" ? 'selected' : ''); ?>>Asturias</option>
                                        <option value="Ávila" <?php echo e(old('provincia') == "Ávila" ? 'selected' : ''); ?>>Ávila</option>
                                        <option value="Barcelona" <?php echo e(old('provincia') == "Barcelona" ? 'selected' : ''); ?>>Barcelona</option>
                                        <option value="Burgos" <?php echo e(old('provincia') == "Burgos" ? 'selected' : ''); ?>>Burgos</option>
                                        <option value="Cáceres" <?php echo e(old('provincia') == "Cáceres" ? 'selected' : ''); ?>>Cáceres</option>
                                        <option value="Cádiz" <?php echo e(old('provincia') == "Cádiz" ? 'selected' : ''); ?>>Cádiz</option>
                                        <option value="Cantabria" <?php echo e(old('provincia') == "Cantabria" ? 'selected' : ''); ?>>Cantabria</option>
                                        <option value="Castellón" <?php echo e(old('provincia') == "Castellón" ? 'selected' : ''); ?>>Castellón</option>
                                        <option value="Ciudad Real" <?php echo e(old('provincia') == "Ciudad Real" ? 'selected' : ''); ?>>Ciudad Real</option>
                                        <option value="Córdoba" <?php echo e(old('provincia') == "Córdoba" ? 'selected' : ''); ?>>Córdoba</option>
                                        <option value="Cuenca" <?php echo e(old('provincia') == "Cuenca" ? 'selected' : ''); ?>>Cuenca</option>
                                        <option value="Girona" <?php echo e(old('provincia') == "Girona" ? 'selected' : ''); ?>>Girona</option>
                                        <option value="Granada" <?php echo e(old('provincia') == "Granada" ? 'selected' : ''); ?>>Granada</option>
                                        <option value="Guadalajara" <?php echo e(old('provincia') == "Guadalajara" ? 'selected' : ''); ?>>Guadalajara</option>
                                        <option value="Guipúzcoa" <?php echo e(old('provincia') == "Guipúzcoa" ? 'selected' : ''); ?>>Guipúzcoa</option>
                                        <option value="Huelva" <?php echo e(old('provincia') == "Huelva" ? 'selected' : ''); ?>>Huelva</option>
                                        <option value="Huesca" <?php echo e(old('provincia') == "Huesca" ? 'selected' : ''); ?>>Huesca</option>
                                        <option value="Islas Baleares" <?php echo e(old('provincia') == "Islas Baleares" ? 'selected' : ''); ?>>Islas Baleares</option>
                                        <option value="Jaén" <?php echo e(old('provincia') == "Jaén" ? 'selected' : ''); ?>>Jaén</option>
                                        <option value="La Rioja" <?php echo e(old('provincia') == "La Rioja" ? 'selected' : ''); ?>>La Rioja</option>
                                        <option value="Las Palmas" <?php echo e(old('provincia') == "Las Palmas" ? 'selected' : ''); ?>>Las Palmas</option>
                                        <option value="León" <?php echo e(old('provincia') == "León" ? 'selected' : ''); ?>>León</option>
                                        <option value="Lleida" <?php echo e(old('provincia') == "Lleida" ? 'selected' : ''); ?>>Lleida</option>
                                        <option value="Lugo" <?php echo e(old('provincia') == "Lugo" ? 'selected' : ''); ?>>Lugo</option>
                                        <option value="Madrid" <?php echo e(old('provincia') == "Madrid" ? 'selected' : ''); ?>>Madrid</option>
                                        <option value="Málaga" <?php echo e(old('provincia') == "Málaga" ? 'selected' : ''); ?>>Málaga</option>
                                        <option value="Murcia" <?php echo e(old('provincia') == "Murcia" ? 'selected' : ''); ?>>Murcia</option>
                                        <option value="Navarra" <?php echo e(old('provincia') == "Navarra" ? 'selected' : ''); ?>>Navarra</option>
                                        <option value="Ourense" <?php echo e(old('provincia') == "Ourense" ? 'selected' : ''); ?>>Ourense</option>
                                        <option value="Palencia" <?php echo e(old('provincia') == "Palencia" ? 'selected' : ''); ?>>Palencia</option>
                                        <option value="Pontevedra" <?php echo e(old('provincia') == "Pontevedra" ? 'selected' : ''); ?>>Pontevedra</option>
                                        <option value="Salamanca" <?php echo e(old('provincia') == "Salamanca" ? 'selected' : ''); ?>>Salamanca</option>
                                        <option value="S. C. Tenerife" <?php echo e(old('provincia') == "S. C. Tenerife" ? 'selected' : ''); ?>>S. C. Tenerife</option>
                                        <option value="Segovia" <?php echo e(old('provincia') == "Segovia" ? 'selected' : ''); ?>>Segovia</option>
                                        <option value="Sevilla" <?php echo e(old('provincia') == "Sevilla" ? 'selected' : ''); ?>>Sevilla</option>
                                        <option value="Soria" <?php echo e(old('provincia') == "Soria" ? 'selected' : ''); ?>>Soria</option>
                                        <option value="Tarragona" <?php echo e(old('provincia') == "Tarragona" ? 'selected' : ''); ?>>Tarragona</option>
                                        <option value="Teruel" <?php echo e(old('provincia') == "Teruel" ? 'selected' : ''); ?>>Teruel</option>
                                        <option value="Toledo" <?php echo e(old('provincia') == "Toledo" ? 'selected' : ''); ?>>Toledo</option>
                                        <option value="Valencia" <?php echo e(old('provincia') == "Valencia" ? 'selected' : ''); ?>>Valencia</option>
                                        <option value="Valladolid" <?php echo e(old('provincia') == "Valladolid" ? 'selected' : ''); ?>>Valladolid</option>
                                        <option value="Vizcaya" <?php echo e(old('provincia') == "Vizcaya" ? 'selected' : ''); ?>>Vizcaya</option>
                                        <option value="Zamora" <?php echo e(old('provincia') == "Zamora" ? 'selected' : ''); ?>>Zamora</option>
                                        <option value="Zaragoza" <?php echo e(old('provincia') == "Zaragoza" ? 'selected' : ''); ?>>Zaragoza</option>
                                        <option value="PD" <?php echo e(old('provincia') == "PD" ? 'selected' : ''); ?>>Por definir</option>
                                    </select>
                                    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group col-md-8 mx-auto">
                                    <label for="term_municipal" class="col-form-label text-md-center">Término municipal</label>
                                    <input id="term_municipal" type="text" class="form-control <?php $__errorArgs = ['term_municipal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" title="Tamaño máximo 80 caracteres" name="term_municipal" value="<?php echo e(old('term_municipal')); ?>" autocomplete="term_municipal">
                                    <?php $__errorArgs = ['term_municipal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                <div class="form-group col-md-8 mx-auto">
                                    <label for="sociedad" class="col-form-label text-md-center">Sociedad</label>
                                    <input id="sociedad" type="text" class="form-control <?php $__errorArgs = ['sociedad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" title="Tamaño máximo 80 caracteres"name="sociedad" value="<?php echo e(old('sociedad')); ?>" autocomplete="sociedad">
                                    <?php $__errorArgs = ['sociedad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback d-block" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                
                                
                                <div class="form-group row col-md-8 mx-auto">
                                    <button class="btn btn-primary mx-auto d-block" title="Alta de Proyecto"><i class="fas fa-save"></i></button>
                                    <button type="reset" class="btn btn-danger mx-auto d-block" title="Limpiar campos"><i class="fas fa-times"></i></button>
                                    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary mx-auto d-block" title="Volver atrás sin guardar datos">
                                        <i class="fas fa-reply"></i>
                                    </a>
                                </div>
                                
                                
                            </div>
                        </fieldset>   
                          
                    </div>
                      
               
                </form>
            
        
             
            

<?php $__env->stopSection(); ?>


  


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/proyectos/index.blade.php ENDPATH**/ ?>