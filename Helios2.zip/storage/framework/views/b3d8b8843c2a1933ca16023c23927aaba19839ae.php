

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>



    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>


   <fieldset class="border p-2  col-md-12">
    <legend class="w-auto">Detalle del Proyecto: <?php echo e($proyecto->nom_proyecto); ?></legend>                                   

        <div class="card-body">

        <select name="proyecto-id" id="proyecto-id" style="visibility:hidden">
                <option value=" <?php echo e($proyecto->id); ?> " selected> <?php echo e($proyecto->id); ?> </option>

        </select>
                    
                    
            <div class="col-md-12">
            <div class="table-responsive">

             <table class="table table-hover table-bordered" style="text-align:center;">
               
                        <thead>
                            <tr class="table-primary">
                                <th scope="col">Nombre del proyecto</th>
                                <th scope="col">Provincia</th>
                                <th scope="col">Term. Municipal</th>
                                <th scope="col">Técnico</th>
                                <th scope="col">Nº expedientes</th>
                                
                                <th scope="col">Opciones</th>
                            </tr>
                        </thead>               
                        
                        <tbody>
                  
                            <tr>
                                <td><?php echo e($proyecto->nom_proyecto); ?></td>
                                <td><?php echo e($proyecto->provincia); ?></td>
                                <td><?php echo e($proyecto->term_municipal); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($organismos->count()); ?></td>
                                
                                <td>
                                    <div>
                                         
                                      
                                        <div class="btn btn-sm btn-primary" title="Añadir organismo" 
                                        id="boton-alta-org">
                                            <i class="fas fa-plus-square"></i>
                                        </div>
                                        
                                        <a href="/propietarios/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Ver propietarios">
                                        <i class="fas fa-users"></i>
                                        </a>
                                        
                                        <a href="/buscador" class="btn btn-sm btn-primary" title="Volver al buscador de proyectos">
                                        <i class="fas fa-solar-panel"></i>
                                        </a>
                                        
                                    </div>
                                </td>
                            </tr>
                                                                                       
                        </tbody>   
                            
                    </table>
            </div>
        </div>
        </div>
      </fieldset>

    <br>

    <fieldset class="border p-2  col-md-12">
            <legend class="w-auto">Hitos de <?php echo e($proyecto->nom_proyecto); ?></legend>     
            <div class="table-responsive">
                
                <table class="table table-hover table-bordered" style="text-align:center;">
                
                <tr class="table-primary">

                    <th scope="col">Hitos</th>
                    <th scope="col">Solicitud Ind.</th>
                    <th scope="col">Obtención Ind.</th>
                    <th scope="col">Comunicación Dist.</th>
                    <th scope="col">Contestación</th>


                </tr>

                <?php $__currentLoopData = $hitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td width="10%"><a href="/hito/<?php echo e($hito->id); ?>">Nº <?php echo e($hito->hito_numero); ?> </a></td>

                    
                    <td><?php if($hito->fec_sol_ind): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_sol_ind->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                    </td>
                    
                    <td><?php if($hito->fec_obt_ind): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_obt_ind->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                    </td>
                    
                    <td><?php if($hito->fec_com_dis): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_com_dis->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                    </td>
                    
                    <td><?php if($hito->fec_contest): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_contest->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                    </td>
                    
                                                    

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                
            </table>
            </div>
        </fieldset>
            
       

    <br>
  
     <fieldset class="border p-1  col-md-12">
        <legend class="w-auto"><div id="organismo">Datos del organismo:</div></legend>                                 
                <div class="card-body">
                <div class="col-md-12">
                    <select class="form-control w-auto mb-2" id="select-organismo" name="select-organismo">
                        <option value="-1" selected disabled>Selecciona organismo</option>
                        <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <option value=" <?php echo e($org->id); ?> "> <?php echo e($org->organismo); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                <div class="table-responsive">
                <table class="table table-hover table-bordered" style="text-align:center;">
                        <tr class="table-primary">
                            <th scope="col">Expediente</th>
                            <th scope="col">Presentación</th>
                            <th scope="col">Requerimiento</th>
                            <th scope="col">Cont. Requerimiento</th>
                            <th scope="col">Inf. pública</th>
                            <th scope="col">Fin inf. pública</th>
                            <th scope="col">Resolución</th>
                        </tr>
                        <tr>
                            <td><div id="num-expediente">-</div></td>
                            <td><div id="fec-presentacion">-</div></td>
                            <td><div id="fec-requerimiento">-</div></td>
                            <td><div id="fec-cont-requerimiento">-</div></td>
                            <td><div id="fec-inicio-ip">-</div></td>
                            <td><div id="fec-fin-ip">-</div></td>
                            <td><div id="fec-resolucion">-</div></td>
                        </tr>
                        <tr class="table-primary">
                            
                            <th scope="col">Publicación res.</th>
                            <th scope="col">Caducidad</th>
                            <th scope="col">Solicitud prórroga</th>
                            <th scope="col">Concesión prórroga</th>
                            <th scope="col">Nº prórrogas</th>
                            <th scope="col">Solicitud APM</th>
                            <th scope="col">Concesión APM</th>
                        </tr>
                        <tr>
                            
                            <td><div id="fec-publ-resolucion">-</div></td>
                            <td><div id="fec-caducidad">-</div></td>
                            <td><div id="fec-solic-prorroga">-</div></td>
                            <td><div id="fec-concesion-pror">-</div></td>
                            <td><div id="num-prorrogas">-</div></td>
                            <td><div id="fec-solic-apm">-</div></td>
                            <td><div id="fec-conc-apm">-</div></td>
                        </tr>
            
                      </table>
            </div>
        </div>
                    
            <table class="table table-bordered" style="text-align:center;">  
                
                <tr class="table-primary">
                    <th scope="col" width="100%" style="text-align:left;">Observaciones: </th>
                </tr>
                <tr>
                    <td>
                        <div class="col-md-12" style="text-align:left;" id="observaciones">-</div>
                    </td>
                </tr>
                
            </table>
                    
            <br>
                
            <div style="text-align:center;">
                <div class="btn btn btn-primary" title="Editar organismo/expediente" id="boton-editar-org" style="display:none">
                    <i class="far fa-edit" ></i>
                </div>
                
                <div class="btn btn btn-success" id="boton-finalizar-org" title="Dar el organismo/expediente por finalizado" style="display:none">
                    <i class="fas fa-flag-checkered"></i>
                </div>

                <div class="btn btn btn-danger" id="boton-eliminar-org" title="Dar de baja organismo/expediente" style="display:none">
                    <i class="fas fa-trash-alt"></i>
                </div> 
            </div>
        </div>
                       
</fieldset>
<br>
                    
                    
        

                        
     

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/ver.js"></script>
    

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Helios\resources\views/proyectos/ver.blade.php ENDPATH**/ ?>