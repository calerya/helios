<?php $__env->startSection('content'); ?>

    <?php if(session('busqueda')): ?>
    <div class="alert alert-dismissible alert-warning">
        <?php echo e(session('busqueda')); ?>

    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
        <a class="navbar-brand" href="#">Buscar proyectos</a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        
    <div class="collapse navbar-collapse" id="navbarColor03">
        
                <form class="form-inline my-2 my-lg-0" method="GET">
                    
                        <div class="form-group mr-sm-2">  
                            <select class="form-control" id="selecciona_listado" name="selecciona_listado" title="Selecciona el listado que deseas obtener">
                            <option value='-1'>Selecciona listado</option>
                           
                            <option value="Caducidad" <?php if(session('seleccionado')=='Caducidad'): ?> selected  <?php endif; ?>>Caducados o que caducan en 30 días</option>

                            <option value="Requerimiento" <?php if(session('seleccionado')=='Requerimiento'): ?> selected  <?php endif; ?>>Sin contestación del requerimiento</option>
                            </select>
                        </div>
                    
                    
                         <div class="form-group mr-sm-2">
                            <button class="btn btn-secondary my-2 my-sm-0" type="submit">Listado</button>
                         </div>    
                        
                         <div class="form-group mr-sm-2">
                            <a id='enpdf' class="btn btn-secondary my-2 my-sm-0">Descargar PDF</a>
                         </div>    
                        
                                                   
             </form>
      
          </div>
        
        
        
       
</nav>

     <br>    

    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-10">
             <legend class="w-auto">Listado de organismos</legend>        
               
       
                <table class="table table-hover-2" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <th scope="col">Organismo</th>
                        <th scope="col">Expediente</th>
                        <th scope="col">Presentación</th>
                        <th scope="col">Requerimiento</th>
                        <th scope="col">Cont. requerimiento</th>
                        <th scope="col">Caducidad</th>
                        <th scope="col">Opciones</th>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($organismo->organismo); ?></td>
                        <td><?php echo e($organismo->num_expediente); ?></td>
                        <td><?php echo e($organismo->fec_presentacion->format('d/m/Y')); ?></td>
                        <td><?php echo e($organismo->fec_requerimiento); ?></td>
                        <td><?php echo e($organismo->fec_cont_requerimiento); ?></td>
                        <td><?php echo e($organismo->fec_caducidad); ?></td>
                        <td>
                            
                            <a href="/proyecto/<?php echo e($organismo->proyecto_id); ?>/ver" class="btn btn-sm btn-primary" title="Ver">
                                <i class="far fa-eye"></i>
                            </a>
                            
                            <a href="/proyecto/<?php echo e($organismo->proyecto_id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                            <a href='/organismo/<?php echo e($organismo->proyecto_id); ?>/ver' class="btn btn-sm btn-primary" title="Añadir organismo" id="boton-alta-oproyectorg" >
                                <i class="fas fa-plus-square"></i>
                            </a>
                            
                                                        
                            <a href="/proyecto/<?php echo e($organismo->proyecto_id); ?>/eliminar" class="btn btn-sm btn-danger" title="Dar de baja" onclick="return confirm('Eliminar el proyecto y sus organismos?')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                           
                </tbody>
                    
                   
                    
            </table>
            
         
                  
        </fieldset>    
        
     
        
</div>

<?php echo e($organismos->withQueryString()->links()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/listados.js"></script>
    

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/helios/resources/views/proyectos/listado.blade.php ENDPATH**/ ?>