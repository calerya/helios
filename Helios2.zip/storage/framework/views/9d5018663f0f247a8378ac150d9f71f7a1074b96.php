

<?php $__env->startSection('content'); ?>

    
    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

   
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
                
                <div class="card-header text-md-center">
                    <h5>Recuperar organismos eliminados</h5>
                </div>
                    
                <table class="table table-hover-2" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <th scope="col" width="8%"><small>Proyecto</small></th>
                        <th scope="col" width="8%"><small>Organismo</small></th>
                        <th scope="col" width="8%"><small>Expediente</small></th>
                        <th scope="col" width="7%"><small>Eliminado</small></th>
                        <th scope="col" width="7%"><small>Requerimiento</small></th>
                        <th scope="col" width="7%"><small>Contest. req.</small></th>
                        <th scope="col" width="7%"><small>Resolución</small></th>
                        <th scope="col" width="7%"><small>Caducidad</small></th>
                        <th scope="col" width="7%"><small>Sol. prórroga</small></th>
                        <th scope="col" width="7%"><small>Concesión</small></th>
                        <th scope="col" width="7%"><small>Solic. APM</small></th>
                        <th scope="col" width="7%"><small>Conc. APM</small></th>
                        <th scope="col" width="13%"><small>Opciones</small></th>
                    </tr>
                </thead>
                
                <tbody>
                <?php if($organismos): ?>
                
                    <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="8%" class="text-danger"><?php echo e($organismo->nombre); ?></td>
                        <td width="8%"><small><?php echo e($organismo->organismo); ?></small></td>
                        <td width="8%"><small><?php echo e($organismo->num_expediente); ?></small></td>
                        <td width="7%"><small><?php if($organismo->deleted_at): ?> <?php echo e($organismo->deleted_at->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_requerimiento): ?> <?php echo e($organismo->fec_requerimiento->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_cont_requerimiento): ?> <?php echo e($organismo->fec_cont_requerimiento->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_resolucion): ?> <?php echo e($organismo->fec_resolucion->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_caducidad): ?> <?php echo e($organismo->fec_caducidad->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_solic_prorroga): ?> <?php echo e($organismo->fec_solic_prorroga->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_concesion_pror): ?> <?php echo e($organismo->fec_concesion_pror->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_solic_apm): ?> <?php echo e($organismo->fec_solic_apm->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_conc_apm): ?> <?php echo e($organismo->fec_conc_apm->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        
                        <td width="13%">
                                                                              
                            <a href="/recuperar/<?php echo e($organismo->id); ?>/organismos" class="btn btn-sm btn-success" title="Recuperar el organismo"><i class="fas fa-upload"></i>
                            </a>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   <?php endif; ?>    
                 
              
                </tbody>      
                    
            </table>
            
    <?php if(!is_null($organismos)): ?>
        <?php if($organismos->count()==0): ?>
      
        <div class="row justify-content-center align-items-center">
            <h5>No hay registros que cumplan con el criterio seleccionado</h5>
        </div>    
    <?php endif; ?>
    <?php endif; ?>        
            
      
     
        
</div>

<?php if($organismos): ?>
<?php echo e($organismos->withQueryString()->links()); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/helios/resources/views/admin/users/eliminados/organismos.blade.php ENDPATH**/ ?>