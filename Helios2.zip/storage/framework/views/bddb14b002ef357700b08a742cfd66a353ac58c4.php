

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    
    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-1 col-md-12">
          <legend class="w-auto">Hitos de <?php echo e($proyecto->nom_proyecto); ?></legend>
                    
               <div class="card card-body">
                <div class="col-md-12 mt-2" style="text-align:left;">
                  <div class="table-responsive">
                    <table class="table table-hover table-bordered" style="text-align:center;">
                      <tr class="table-active">
                        <th scope="col">Hitos</th>
                        <th scope="col">Solicitud Ind.</th>
                        <th scope="col">Obtención Ind.</th>
                        <th scope="col">Comunicación Dist.</th>
                        <th scope="col">Contestación</th>
                      </tr>
      
                      <?php $__currentLoopData = $hitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          
                          <td width="10%"><a href="/hito/<?php echo e($hito->id); ?>">Nº <?php echo e($hito->hito_numero); ?> </a></td>
      
                          
                          <td><?php if($hito->fec_sol_ind): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_sol_ind->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                          </td>
                          
                          <td><?php if($hito->fec_obt_ind): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_obt_ind->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                          </td>
                          
                          <td><?php if($hito->fec_com_dis): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_com_dis->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                          </td>
                          
                          <td><?php if($hito->fec_contest): ?><div style="background-color: rgb(242, 243, 243); color: grey;" type="date" class="form-control text-md-center"><?php echo e($hito->fec_contest->format('d-m-Y')); ?></div><?php else: ?><div class="form-control text-md-center">-</div><?php endif; ?>
                          </td>
                        
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>
                </div>
                </div>
        </fieldset>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/hitos/ver.blade.php ENDPATH**/ ?>