

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-danger">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('activado')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('activado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('busqueda')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('busqueda')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      
        <a class="navbar-brand" href="#">Buscar proyectos</a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarColor03">
               
            <?php echo e(Form::open(['route' => 'finalizados', 'method' => 'GET', 'class' => 'form-inline  float-right' ])); ?>

          
             <div class="navbar-nav">
                 <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('nom_proyecto',null,['class' => 'form-control','placeholder' => 'Nombre proyecto'])); ?>

                </div>
                <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('provincia',null,['class' => 'form-control','placeholder' => 'Provincia'])); ?>

                </div>
                <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('term_municipal',null,['class' => 'form-control','placeholder' => 'Término municipal'])); ?>

                </div>
                            
                 <div class="form-group mr-sm-2">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">Buscar</button>
                </div>
                 
            </div>
          
            <?php echo e(Form::close()); ?>

            
           
      </div>
    </nav>

     <br>    

   
    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-12">
             <legend class="w-auto">Listado de proyectos finalizados</legend>        
               
       
                <div class="col-md-12">
                <div class="table-responsive">
          
                 <table class="table table-hover table-bordered" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <div><th width="22%" scope="col">Nombre</th></div>
                        <div><th width="10%" scope="col">Provincia</th></div>
                        <div><th width="22%"scope="col">Término municipal</th></div>
                        <div><th width="17%" scope="col">Sociedad</th></div>
                        <div><th width="9%" scope="col">Alta</th></div>
                        <div><th width="10%" scope="col">Total org.</th></div>
                        <div><th width="10%" scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div><td width="22%"><a href="/proyecto/<?php echo e($proyecto->id); ?>/ver"><?php echo e($proyecto->nom_proyecto); ?></a></td></div>
                        <div><td width="10%"><?php echo e($proyecto->provincia); ?></td></div>
                        <div><td width="22%"><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div><td width="17%"><?php echo e($proyecto->sociedad); ?></td></div>
                        <div><td width="9%"><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td></div>
                        <div><td width="10%"><?php echo e($proyecto->tot); ?></td></div>
                        <div><td width="10%">
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/excel" class="btn btn-sm btn-primary" title="Descargar EXCEL del proyecto"><i class="fas fa-file-excel"></i></a>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/activar" class="btn btn-sm btn-warning" title="Volver a activar el proyecto">
                                <i class="fas fa-flag-checkered"></i>
                            </a>
                            
                            
                        </td></div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                           
                </tbody>
                    
                   
                   <?php echo e($proyectos->render()); ?>      
            </table>
            </div>       
            </div>
            
            <?php if(!is_null($proyectos)): ?>
        <?php if($proyectos->count()==0): ?>
      
        <div class="row justify-content-center align-items-center">
            <h5>No hay registros que cumplan con el criterio seleccionado</h5>
        </div>    
    <?php endif; ?>
    <?php endif; ?>   
            
                  
        </fieldset>    
        
     
        
</div>

                  
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/proy_buscador.js"></script>
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Helios\resources\views/proyectos/finalizados.blade.php ENDPATH**/ ?>