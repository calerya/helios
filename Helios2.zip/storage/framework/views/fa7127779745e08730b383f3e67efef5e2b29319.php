<?php $__env->startSection('content'); ?>

    <form action="" method="post">    
      
        <?php echo csrf_field(); ?>

        <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header">
                    <h4>Alta de un proyecto</h4>
                </div>

                <div class="card-body">
                    
                    
                        
                        <div class="row">
                            
                            <div class="form-group col-md-4">
                                <label for="nom_proyecto">Nombre del proyecto</label>
                                <input type="text" name="nom_proyecto" class="form-control" autofocus>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="num_expediente">Número de expediente</label>
                                <input type="text" placeholder="Introduzca el número de expediente" class="form-control" required>
                            </div>

                            <div class="form-group col-md-4">
                                <label for="provincia">Provincia</label>
                                <select name="provincia" class="form-control">
                                    <option value="PD">Por definir</option>
                                    <option value="Madrid">Madrid</option>
                                    <option value="Toledo">Toledo</option>
                                    <option value="Valladolid">Valladolid</option>
                                </select>
                            
                            </div>
                        
                        </div>
                        
                        <div class="row">
                            
                            <div class="form-group col-md-4">
                                <label for="term_municipal">Término municipal</label>
                                <input type="text" placeholder="Introduzca el término municipal" class="form-control">
                            </div>

                            <div class="form-group col-md-4">
                                <label for="sociedad">Sociedad</label>
                                <input type="text" placeholder="Introduzca la sociedad" class="form-control">
                            </div>

                            <div class="form-group col-md-4">
                                <label for="organismo">Organismo</label>
                                <input type="text" placeholder="Introduzca el organismo" class="form-control">
                            
                            </div>
                        
                        </div>
                        
                    
                </div>
            </div>
        
        <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header">
                    <h4>Fechas en el organismo</h4>
                </div>

                <div class="card-body">
                                                                
                        <div class="row">
                            
                            <div class="form-group col-md-2">
                                <label for="fec_presentacion">Presentación</label>
                                <input type="date" name="fec_presentacion" class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label for="fec_requerimiento">Requerimiento</label>
                                <input type="date" name="fec_requerimiento" class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label for="fec_cont_requerimiento">Contestación</label>
                                <input type="date" name="fec_cont_requerimiento" class="form-control">
                            </div>
                            
                            <div class="form-group col-md-2">
                                <label for="fec_inicio_ip">Inicio IP</label>
                                <input type="date" name="fec_inicio_ip" class="form-control">
                            </div>
                            
                            <div class="form-group col-md-2">
                                <label for="fec_fin_ip">Fin IP</label>
                                <input type="date" name="fec_fin_ip" class="form-control">
                            </div>
                            
                            <div class="form-group col-md-2">
                                <label for="fec_resolucion">Resolución</label>
                                <input type="date" name="fec_resolucion" class="form-control">
                            </div>
                            
                            
                        </div>
                    
                    <div class="row">
                            
                                            
                        
                            <div class="form-group col-md-2">
                                <label for="fec_publ_resolucion">Publicación</label>
                                <input type="date" name="fec_publ_resolucion" class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label for="fec_caducidad">Caducidad</label>
                                <input type="date" name="fec_caducidad" class="form-control">
                            </div>

                            <div class="form-group col-md-2">
                                <label for="fec_solic_prorroga">Prórroga</label>
                                <input type="date" name="fec_solic_prorroga" class="form-control">
                            </div>
                        
                            <div class="form-group col-md-2">
                                <label for="num_prorrogas">Prórrogas</label>
                                <input type="number" placeholder="Seleccione nº" min='0' step="1" class="form-control">
                            </div>
                        
                            <div class="form-group col-md-2">
                              
                                  <p>Proyecto finalizado</p>
                             
                                    <label class="radio-inline">
                                      <input type="radio" name="finalizado" value=false checked> No
                                    </label>
                                    <label class="radio-inline">
                                      <input type="radio" name="finalizado" value=true> Si
                                    </label>
                                 
                               
                                </div>
                        
                            <div class="form-group col-md-2">
                                <label for="fec_finalizacion">Finalización</label>
                                <input type="date" name="fec_finalizacion" class="form-control">
                            </div>
                         
                        </div>
                    
                </div>
            </div>
                
        
        
        <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header">
                    <h4>Info adicional</h4>
                </div>

                <div class="card-body">
                                                                
                        <div class="row">
                            
                            

                            <div class="form-group col-md-12">
                                <label for="observaciones">Observaciones</label>
                                <textarea name="comentarios" rows="10" cols="40" class="form-control">Escribe aquí tus observaciones</textarea>
                            </div>
                         
                            <div class="form-group">
                                <button type="button" class="btn btn-primary">Alta de proyecto</button>
                            </div>
                            
                    
                        </div>
                    
                </div>
            
        </div>

        
  
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/altaorganismo.blade.php ENDPATH**/ ?>