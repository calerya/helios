

<?php $__env->startSection('styles'); ?>
<link 
rel="stylesheet" 
href="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.css" 
integrity="sha512-CWdvnJD7uGtuypLLe5rLU3eUAkbzBR3Bm1SFPEaRfvXXI2v2H5Y0057EMTzNuGGRIznt8+128QIDQ8RqmHbAdg==" 
crossorigin="anonymous" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    <fieldset class="border col-md-12">
        <legend class="w-auto">Alta de finca en el proyecto <?php echo e($proyecto->nom_proyecto); ?></legend>  
            
            <datos-catastro></datos-catastro>
        
    
                 
        <form action="<?php echo e(route('fincas.store',['id' => $proyecto->id])); ?>" method="post" novalidate>
            <?php echo e(csrf_field()); ?>


            
            

            <div class="card-body">
                <div class="col-md-12">
                <div class="table-responsive form-group">
          
                 <table class="table table-hover table-bordered" style="text-align:center;">
                        <tr class="table-active">
                            <th width="20%" scope="col">Ref Catastral</th>
                            <th scope="col">Provincia</th>
                            <th scope="col">Municipio</th>
                            <th scope="col">Zona</th>
                            <th width="9%" scope="col">Polígono</th>
                            <th width="9%" scope="col">Parcela</th>
                            <th width="9%" scope="col">Uso</th>
                        </tr>
                        
                        <tr>
                            
                            <td width="20%">
                                <input
                                    id="ref_catastral"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['ref_catastral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="20 caracteres - Ref. Catastral"
                                    name="ref_catastral"
                                    value="<?php echo e(old('ref_catastral')); ?>"
                                    >
                                    
                                    <?php $__errorArgs = ['ref_catastral'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td>
                                <input
                                    id="provincia"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Provincia"
                                    name="provincia"
                                    value="<?php echo e(old('provincia')); ?>"
                                    >
                                    <?php $__errorArgs = ['provincia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td>
                                <input
                                    id="municipio"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Municipio"
                                    name="municipio"
                                    value="<?php echo e(old('municipio')); ?>"
                                    >
                                    <?php $__errorArgs = ['municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td>
                                <input
                                    id="zona"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['zona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Zona"
                                    name="zona"
                                    value="<?php echo e(old('zona')); ?>"
                                    >
                                    <?php $__errorArgs = ['zona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td width="9%" >
                                <input
                                    id="poligono"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['poligono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Polígono"
                                    name="poligono"
                                    value="<?php echo e(old('poligono')); ?>"
                                   >
                                    <?php $__errorArgs = ['poligono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td width="9%" >
                                <input
                                    id="parcela"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['parcela'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Parcela"
                                    name="parcela"
                                    value="<?php echo e(old('parcela')); ?>"
                                    >
                                    <?php $__errorArgs = ['parcela'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td width="9%" >
                                <input
                                    id="uso"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['uso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="Uso"
                                    name="uso"
                                    value="<?php echo e(old('uso')); ?>"
                                    >
                                    <?php $__errorArgs = ['uso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>
                        <tr  class="table-active">
                            <th scope="col">Venta / Alq</th>
                            <th scope="col">Sup. Cat. ha</th>
                            <th scope="col">Sup. Útil ha</th>
                        </tr>
                        <br>
                        <tr>
                            
                            <td>
                                <select 
                                    name="venta_alq" 
                                    class="form-control 
                                    <?php $__errorArgs = ['venta_alq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                    title="Finca en venta o alquiler" 
                                    value="<?php echo e(old('venta_alq')); ?>">
                                        <option disabled selected>-- Seleccione --</option>
                                        <option value="venta" <?php echo e(old('venta_alq') == "venta" ? 'selected' : ''); ?>>Venta</option>
                                        <option value="alquiler" <?php echo e(old('venta_alq') == "alquiler" ? 'selected' : ''); ?>>Alquiler</option>
                                        <option value="otro" <?php echo e(old('venta_alq') == "otro" ? 'selected' : ''); ?>>Otro</option>
                                </select>
                                    
                                <?php $__errorArgs = ['venta_alq'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td>
                                <input
                                    id="sup_catastral_ha"
                                    type="number" step="0.01" min="0" lang="es"
                                    
                                    class="form-control text-md-center <?php $__errorArgs = ['sup_catastral_ha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="formato x,xxxx"
                                    name="sup_catastral_ha"
                                    value="<?php echo e(old('sup_catastral_ha')); ?>"
                                    >
                                    <?php $__errorArgs = ['sup_catastral_ha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                            
                            <td>
                                <input
                                    id="sup_util_ha"
                                    type="text"
                                    class="form-control text-md-center <?php $__errorArgs = ['sup_util_ha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    placeholder="formato x,xxxx"
                                    name="sup_util_ha"
                                    value="<?php echo e(old('sup_util_ha')); ?>"
                                    >
                                    <?php $__errorArgs = ['sup_util_ha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback">
                                            <?php echo e($message); ?>

                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </td>
                        </tr>

                 </table>
                
                 <div class="card border-light mb-1">
                    <div class="card-body">
                      <div class="card-title"><strong>Observaciones:</strong>
                        <button class="btn btn-primary ml-3" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                            Mostrar / Ocultar observaciones
                            </button>
                      </div>
                                            
                 </div>
                  <div class="collapse" id="collapseExample">
                    <div class="card card-body">
                        
                        <div class="col-md-12 mt-2" style="text-align:left;">
                            <input title="Añada sus observaciones al expediente" id="observaciones" type="hidden"
                            name="observaciones" value="<?php echo e(old('observaciones')); ?>">
                            <trix-editor input="observaciones" class="form-control text-md-left"></trix-editor>
                        </div>
                    </div>
                  </div>
                </div>

                 
                        
               
                    
                    


                </div>
                </div>
            </div>
            <input
                    id="proyecto_id"
                    name="proyecto_id"
                    value=<?php echo e($proyecto->id); ?>

                    type="hidden"
            >
            <div class="text-md-center mb-3 mt-1">
                <button class="btn btn-primary mr-2" title="Alta de Proyecto"><i class="fas fa-save"></i></button>
                <button type="reset" class="btn btn-danger" title="Limpiar campos"><i class="fas fa-times"></i></button>
                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary ml-2" title="Volver atrás sin guardar datos">
                    <i class="fas fa-reply"></i>
                </a>
            </div>
            </fieldset>

        </form>

                     
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('scripts'); ?>
    <script 
        src="https://cdnjs.cloudflare.com/ajax/libs/trix/1.3.1/trix.js" 
        integrity="sha512-/1nVu72YEESEbcmhE/EvjH/RxTg62EKvYWLG3NdeZibTCuEtW5M4z3aypcvsoZw03FAopi94y04GhuqRU9p+CQ==" 
        crossorigin="anonymous" defer>
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/fincas/create.blade.php ENDPATH**/ ?>