<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
                
            <form action="" method="post">
                
                <?php echo e(csrf_field()); ?>

        
                                                                                       
                

                        <div class="card-body">
                            <fieldset class="border p-2">
                                <legend class="w-auto">Alta de proyecto</legend>                
                            <div class="form-group row"> 
                                <label for="nom_proyecto" class="col-md-3 col-form-label text-md-center">Proyecto</label>
                                <label for="provincia" class="col-md-2 col-form-label text-md-center">Provincia</label>
                                <label for="term_municipal" class="col-md-3 col-form-label text-md-center">Term. municipal</label>
                                <label for="sociedad" class="col-md-2 col-form-label text-md-center">Sociedad</label>
                                <label for="opciones" class="col-md-2 col-form-label text-md-center">Opciones</label>
                            </div>

                            <div class="form-group row"> 
                                <div class="col-md-3">
                                    <input id="nom_proyecto" type="text" class="form-control" name="nom_proyecto" value="<?php echo e(old('nom_proyecto')); ?>" required autocomplete="nom_proyecto" autofocus>
                                </div>
                                
                                <div class="col-md-2">
                                    <select name="provincia" class="form-control" title="Selecciona la provincia del proyecto" value="<?php echo e(old('provincia')); ?>" required autocomplete="provincia">
                                        <option value="">Seleccione provincia</option>
                                        <option value="A Coruña">A Coruña</option>
                                        <option value="Álava">Álava</option>
                                        <option value="Albacete">Albacete</option>
                                        <option value="Alicante">Alicante</option>
                                        <option value="Almería">Almería</option>
                                        <option value="Asturias">Asturias</option>
                                        <option value="Ávila">Ávila</option>
                                        <option value="Barcelona">Barcelona</option>
                                        <option value="Burgos">Burgos</option>
                                        <option value="Cáceres">Cáceres</option>
                                        <option value="Cádiz">Cádiz</option>
                                        <option value="Cantabria">Cantabria</option>
                                        <option value="Castellón">Castellón</option>
                                        <option value="Ciudad Real">Ciudad Real</option>
                                        <option value="Córdoba">Córdoba</option>
                                        <option value="Cuenca">Cuenca</option>
                                        <option value="Girona">Girona</option>
                                        <option value="Granada">Granada</option>
                                        <option value="Guadalajara">Guadalajara</option>
                                        <option value="Guipúzcoa">Guipúzcoa</option>
                                        <option value="Huelva">Huelva</option>
                                        <option value="Huesca">Huesca</option>
                                        <option value="Islas Baleares">Islas Baleares</option>
                                        <option value="Jaén">Jaén</option>
                                        <option value="La Rioja">La Rioja</option>
                                        <option value="Las Palmas">Las Palmas</option>
                                        <option value="León">León</option>
                                        <option value="Lleida">Lleida</option>
                                        <option value="Lugo">Lugo</option>
                                        <option value="Madrid">Madrid</option>
                                        <option value="Málaga">Málaga</option>
                                        <option value="Murcia">Murcia</option>
                                        <option value="Navarra">Navarra</option>
                                        <option value="Ourense">Ourense</option>
                                        <option value="Palencia">Palencia</option>
                                        <option value="Pontevedra">Pontevedra</option>
                                        <option value="Salamanca">Salamanca</option>
                                        <option value="S. C. Tenerife">S. C. Tenerife</option>
                                        <option value="Segovia">Segovia</option>
                                        <option value="Sevilla">Sevilla</option>
                                        <option value="Soria">Soria</option>
                                        <option value="Tarragona">Tarragona</option>
                                        <option value="Teruel">Teruel</option>
                                        <option value="Toledo">Toledo</option>
                                        <option value="Valencia">Valencia</option>
                                        <option value="Valladolid">Valladolid</option>
                                        <option value="Vizcaya">Vizcaya</option>
                                        <option value="Zamora">Zamora</option>
                                        <option value="Zaragoza">Zaragoza</option>
                                        <option value="PD">Por definir</option>
                                    </select>
                                </div>
                                
                                <div class="col-md-3">
                                    <input id="term_municipal" type="text" class="form-control" name="term_municipal" value="<?php echo e(old('term_municipal')); ?>" required autocomplete="term_municipal">
                                </div>
                                <div class="col-md-2">
                                    <input id="sociedad" type="text" class="form-control" name="sociedad" value="<?php echo e(old('sociedad')); ?>" required autocomplete="sociedad">
                                </div>
                                <div class="col-md-2 text-md-center">
                                
                                <button class="btn btn-primary" title="Alta de Proyecto"><i class="fas fa-save"></i></button>
                           
                                <button type="reset" class="btn btn-danger" title="Limpiar campos"><i class="fas fa-times"></i></button>
                                
                                <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary" title="Volver atrás sin guardar datos">
                                <i class="fas fa-reply"></i>
                                </a>
                                
                                </div>
                                
                                
                            </div>
                              </fieldset>   
                          
                        </div>
                      
               
                </form>
            
        
             
                    
                <table class="table table-hover" style="text-align:center;">
               
                <thead>
                    <tr class="table-primary">
                        <div class='col-2 col-sm-2'><th scope="col">Nombre</th></div>
                        <div class='col-2 col-sm-2'><th scope="col">Provincia</th></div>
                        <div class='col-2 col-sm-2'><th scope="col">Término municipal</th></div>
                        <div class='col-1 col-sm-1'><th scope="col">Sociedad</th></div>
                        <div class='col-1 col-sm-1'><th scope="col">Dado de alta</th></div>
                        <div class='col-1 col-sm-1'><th scope="col">Tot / Fin</th></div>
                        <div class='col-3 col-sm-3'><th scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div class='col-2 col-sm-2'><td><?php echo e($proyecto->nom_proyecto); ?></td></div>
                        <div class='col-2 col-sm-2'><td><?php echo e($proyecto->provincia); ?></td></div>
                        <div class='col-2 col-sm-2'><td><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div class='col-1 col-sm-1'><td><?php echo e($proyecto->sociedad); ?></td></div>
                        <div class='col-1 col-sm-1'><td><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td></div>
                        <div class='col-1 col-sm-1'><td><?php echo e($proyecto->tot); ?> / <?php echo e($proyecto->fin); ?></td></div>
                        <div class='col-3 col-sm-3'><td>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/ver" class="btn btn-sm btn-primary" title="Ver">
                                <i class="far fa-eye"></i>
                            </a>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/excel" class="btn btn-sm btn-primary" title="Descargar EXCEL del proyecto"><i class="fas fa-file-excel"></i></a>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                            <a href="/organismo/<?php echo e($proyecto->id); ?>/ver" class="btn btn-sm btn-primary" title="Añadir organismo" 
                                id="boton-alta-org" ><i class="fas fa-plus-square"></i>
                            </a>
                            
                                                        
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/eliminar" class="btn btn-sm btn-danger" title="Dar de baja" onclick="return confirm('Eliminar el proyecto y sus organismos?')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td></div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>  
                        
                        
                    
                </div>
                    
     <?php echo e($proyectos->links()); ?>


<?php $__env->stopSection(); ?>


  


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iqlicedk/Helios/resources/views/proyectos/index.blade.php ENDPATH**/ ?>