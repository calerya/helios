

<?php $__env->startSection('content'); ?>

    <?php if(session('busqueda')): ?>
    <div class="alert alert-dismissible alert-warning">
        <?php echo e(session('busqueda')); ?>

    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
        <a class="navbar-brand" href="#">Listado de organismos / expedientes: </a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        
    <div class="collapse navbar-collapse" id="navbarColor03">
        
                <form id="listado_form" class="form-inline my-2 my-lg-0" method="GET">
                    
                        <div class="form-group mr-sm-2">  
                            <select class="form-control" id="selecciona_listado" name="selecciona_listado" title="Selecciona el listado que deseas obtener">
                            <option value='-1'>Selecciona listado</option>
                           
                            <option value="Todos" <?php if(session('seleccionado')=='Todos'): ?> selected  <?php endif; ?>>Todos los organismos / expedientes activos</option>
                                
                            <option value="Caducados" <?php if(session('seleccionado')=='Caducados'): ?> selected  <?php endif; ?>>Caducados o que caducan en 30 días</option>

                            <option value="Requerimiento" <?php if(session('seleccionado')=='Requerimiento'): ?> selected  <?php endif; ?>>Sin contestación del requerimiento</option>
                                
                            <option value="Prorroga" <?php if(session('seleccionado')=='Prorroga'): ?> selected  <?php endif; ?>>Pendientes de conceder la prórroga</option>
                                
                            <option value="APM" <?php if(session('seleccionado')=='APM'): ?> selected  <?php endif; ?>>Pendientes de APM</option>
                                
                            <option value="Con-resolucion" <?php if(session('seleccionado')=='Con-resolucion'): ?> selected  <?php endif; ?>>Con resolución</option>
                                
                            <option value="Sin-resolucion" <?php if(session('seleccionado')=='Sin-resolucion'): ?> selected  <?php endif; ?>>Pendientes de resolución</option>
                                
                            <option value="Finalizados" <?php if(session('seleccionado')=='Finalizados'): ?> selected  <?php endif; ?>>Organismos / expedientes finalizados</option>
                                
                            </select>
                                
                           
                        </div>
                    
                        <div class="form-group mr-sm-2">
                            <a id='enexcel' class="btn btn-sm btn-primary" title="Descargar EXCEL"><i class="fas fa-file-excel"></i></a>
                        </div>
                                                 
                        <!--
                        ANULAMOS LA DESCARGA EN PDF POR TARDAR DEMASIADO
                        <div class="form-group mr-sm-2">
                            <a id='enpdf' class="btn btn-sm btn-primary" title="Descargar en PDF"><i class="far fa-file-pdf fa-2x"></i></a>
                         </div>
                        -->
                    
                        
                        
                                                   
             </form>
      
          </div>
        
        
        
       
</nav>

     <br>    

    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-12">
                    
                <div class="col-md-12">
                <div class="table-responsive">
          
                 <table class="table table-hover table-bordered" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <th scope="col" width="8%"><small>Proyecto</small></th>
                        <th scope="col" width="8%"><small>Organismo</small></th>
                        <th scope="col" width="8%"><small>Expediente</small></th>
                        <th scope="col" width="7%"><small>Presentación</small></th>
                        <th scope="col" width="7%"><small>Requerimiento</small></th>
                        <th scope="col" width="7%"><small>Contest. req.</small></th>
                        <th scope="col" width="7%"><small>Resolución</small></th>
                        <th scope="col" width="7%"><small>Caducidad</small></th>
                        <th scope="col" width="7%"><small>Sol. prórroga</small></th>
                        <th scope="col" width="7%"><small>Concesión</small></th>
                        <th scope="col" width="7%"><small>Solic. APM</small></th>
                        <th scope="col" width="7%"><small>Conc. APM</small></th>
                        <th scope="col" width="13%"><small>Opciones</small></th>
                    </tr>
                </thead>
                
                <tbody>
                <?php if($organismos): ?>
                
                    <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td width="8%" class="text-danger"><a href="/proyecto/<?php echo e($organismo->proyecto_id); ?>/ver"><?php echo e($organismo->nombre); ?></a></td>
                        <td width="8%"><small><?php echo e($organismo->organismo); ?></small></td>
                        <td width="8%"><small><?php echo e($organismo->num_expediente); ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_presentacion): ?> <?php echo e($organismo->fec_presentacion->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_requerimiento): ?> <?php echo e($organismo->fec_requerimiento->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_cont_requerimiento): ?> <?php echo e($organismo->fec_cont_requerimiento->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_resolucion): ?> <?php echo e($organismo->fec_resolucion->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_caducidad): ?> <?php echo e($organismo->fec_caducidad->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_solic_prorroga): ?> <?php echo e($organismo->fec_solic_prorroga->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_concesion_pror): ?> <?php echo e($organismo->fec_concesion_pror->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_solic_apm): ?> <?php echo e($organismo->fec_solic_apm->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        <td width="7%"><small><?php if($organismo->fec_conc_apm): ?> <?php echo e($organismo->fec_conc_apm->format('d/m/Y')); ?> <?php endif; ?></small></td>
                        
                        <td width="13%">
                                                                              
                            <a href="/organismo/<?php echo e($organismo->id); ?>" class="btn btn-sm btn-primary" title="Editar organismo"><i class="far fa-edit"></i>
                            </a>
                            
                            <?php if(session('seleccionado')!='Finalizados'): ?>
                            <a href="/organismo/<?php echo e($organismo->id); ?>/finalizar" class="btn btn-sm btn-success" title="Dar el organismo/expediente por finalizado"><i class="fas fa-flag-checkered"></i>
                            </a>
                            <?php endif; ?>
                            
                            <?php if(session('seleccionado')=='Finalizados'): ?>
                            <a href="/organismo/<?php echo e($organismo->id); ?>/activar" class="btn btn-sm btn-warning" title="Activar el organismo (Ya no estará finalizado)"><i class="fas fa-flag-checkered"></i>
                            </a>
                            <?php endif; ?>
                            
                                                      
                            <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#exampleModal" title="Eliminar el organismo"><i class="fas fa-trash-alt"></i></button>
                            
                            <div class="modal" id="exampleModal">
                              <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                  <div class="modal-header">
                                    <h5 class="modal-title">Eliminar organismo</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                                  <div class="modal-body">
                                      <div class="text-center">
                                        <span class="text-warning"><i style="font-size:70px" class="fas fa-exclamation-circle"></i></span>  
                                    </div>
                                    <p>Quiere eliminar el organismo <?php echo e($organismo->organismo); ?> perteneciente al proyecto <?php echo e($organismo->nombre); ?>?</p>
                                  </div>
                                  <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                      <a href="/organismo/<?php echo e($organismo->id); ?>/eliminar"><button class="btn btn-danger">Eliminar</button></a>
                                  </div>
                                </div>
                              </div>
                            </div>                                
                   
                            
                            
                            <!--        <a href="/organismo/<?php echo e($organismo->id); ?>/eliminar" class="btn btn-sm btn-danger" title="Eliminar " onclick="return confirm('Eliminar el organismo?')">
                                <i class="fas fa-trash-alt"></i>
                            </a> -->
                      
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                   <?php endif; ?>    
                 
              
                </tbody>      
                    
            </table>
            </div>
            </div>
            
    <?php if(!is_null($organismos)): ?>
        <?php if($organismos->count()==0): ?>
      
        <div class="row justify-content-center align-items-center">
            <h5>No hay registros que cumplan con el criterio seleccionado</h5>
        </div>    
    <?php endif; ?>
    <?php endif; ?>        
            
        </fieldset>    
        
     
        
</div>

<?php if($organismos): ?>
<?php echo e($organismos->withQueryString()->links()); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/listados.js"></script>
    

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/organismos/listado.blade.php ENDPATH**/ ?>