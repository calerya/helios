<?php $__env->startSection('content'); ?>




        <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header">
                    <h4>Info del proyecto - Seleccione organismo en el desplegable.</h4>
                </div>

                <div class="card-body">
                    
                    <table class="table table-hover" style="text-align:center;">
               
                        <thead>
                            <tr class="table-primary">
                                <th scope="col">Nombre del proyecto</th>
                                <th scope="col">Provincia</th>
                                <th scope="col">Term. Municipal</th>
                                <th scope="col">Creado por</th>
                                <th scope="col">Nº expedientes</th>
                                <th scope="col">Organismo</th>
                            </tr>
                        </thead>               
                        
                        <tbody>
                  
                            <tr>
                                <td><?php echo e($proyecto->nom_proyecto); ?></td>
                                <td><?php echo e($proyecto->provincia); ?></td>
                                <td><?php echo e($proyecto->term_municipal); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($organismos->count()); ?></td>
                                <td>
                                            <select id="select-organismo" name="select-organismo">
                                                <option value="-1" selected>Selecciona organismo</option>
                                                <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $org): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                 <option value=" <?php echo e($org->id); ?> "> <?php echo e($org->organismo); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            

                                    
                                </td>
                            </tr>
                                                                                       
                        </tbody>   
                            
                    </table>
            </div>
    </div>
                    
            <div class="card border-primary mb-3">
                                                                                       
                <div class="card-body">
                    
                    <table class="table table-hover" style="text-align:center;">
                        <tr>
                            <th scope="col">Expediente</th>
                            <th scope="col">Presentación</th>
                            <th scope="col">Requerimiento</th>
                            <th scope="col">Cont. Requerimiento</th>
                            <th scope="col">Inf. pública</th>
                            <th scope="col">Fin inf. pública</th>
                        </tr>
                        <tr>
                            <td><div id="num-expediente">-</div></td>
                            <td><div id="fec-presentacion">-</div></td>
                            <td><div id="fec-requerimiento">-</div></td>
                            <td><div id="fec_cont_requerimiento">-</div></td>
                            <td><div id="fec-inicio-ip">-</div></td>
                            <td><div id="fec-fin-ip">-</div></td>
                        </tr>
                        <tr>
                            <th scope="col">Resolución</th>
                            <th scope="col">Publicación res.</th>
                            <th scope="col">Caducidad</th>
                            <th scope="col">Solicitud prórroga</th>
                            <th scope="col">Concesión prórroga</th>
                            <th scope="col">Nº prórrogas</th>
                        </tr>
                        <tr>
                            <td><div id="fec-resolucion">-</div></td>
                            <td><div id="fec-publ-resolucion">-</div></td>
                            <td><div id="fec-caducidad">-</div></td>
                            <td><div id="fec-solic-prorroga">-</div></td>
                            <td><div id="fec-concesion-pror">-</div></td>
                            <td><div id="num-prorrogas">-</div></td>
                        </tr>
            </table>
                  
                    
                 
                  <div class="row">
                    <div class="col-md-2" style="text-align:center;"><strong>Observaciones: </strong></div>
                    <div class="col-md-10" style="text-align:left;" id="observaciones">-</div>
                 </div>     
          
             </div>
                       
          </div>
                    
                    
        

                        
     

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/ver.js"></script>

<?php $__env->stopSection(); ?>
  
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/ver.blade.php ENDPATH**/ ?>