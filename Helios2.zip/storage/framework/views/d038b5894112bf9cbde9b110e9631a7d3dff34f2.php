<?php $__env->startSection('content'); ?>


    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    
        
             <div class="card border-primary mb-3">
                                                                                       
                <div class="card-header">
                    <h4>Listado de proyectos activos</h4>
                </div>

                <div class="card-body">
                    
                <table class="table table-hover" style="text-align:center;">
               
                <thead>
                    <tr class="table-primary">
                        <th scope="col">Nombre</th>
                        <th scope="col">Provincia</th>
                        <th scope="col">Término municipal</th>
                        <th scope="col">Sociedad</th>
                        <th scope="col">Dado de alta</th>
                        <th scope="col">Ver</th>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($proyecto->nom_proyecto); ?></td>
                        <td><?php echo e($proyecto->provincia); ?></td>
                        <td><?php echo e($proyecto->term_municipal); ?></td>
                        <td><?php echo e($proyecto->sociedad); ?></td>
                        <td><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td>
                        <td>
                            
                            <a href="ver/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Ver">
                                <i class="far fa-eye"></i>
                            </a>
                            
                   <!--         <a href="/proyecto/<?php echo e($proyecto->id); ?>/eliminar" class="btn btn-sm btn-danger" title="Dar de baja">
                                <i class="fas fa-trash-alt"></i>
                            </a> -->

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>  
                        
                        
                    
                </div>
                    
        </div>
            
 <?php echo e($proyectos->links()); ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views//listado.blade.php ENDPATH**/ ?>