

<?php $__env->startSection('content'); ?>

   <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

   <nav class="navbar navbar-expand-lg navbar-light bg-light">
    
        <a class="navbar-brand" href="#">Listado de proyectos por hitos</a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
        </button>
        
            <div class="collapse navbar-collapse" id="navbarColor03">
            
        
                <form id="hitos_form" class="form-inline my-2 my-lg-0" method="GET">
                    
                        <div class="form-group mr-sm-2">  
                            <select class="form-control" id="selecciona_hito" name="selecciona_hito" title="Selecciona el hito que deseas consultar">
                            <option value='-1'>Selecciona hitos completados</option>
                           
                            <option value='0' <?php if(session('seleccionado')=='0'): ?> selected  <?php endif; ?>>0 hitos</option>
                            <option value='1' <?php if(session('seleccionado')=='1'): ?> selected  <?php endif; ?>>1 hito</option>
                            <option value='2' <?php if(session('seleccionado')=='2'): ?> selected  <?php endif; ?>>2 hitos</option>
                            <option value='3' <?php if(session('seleccionado')=='3'): ?> selected  <?php endif; ?>>3 hitos</option>
                            <option value='4' <?php if(session('seleccionado')=='4'): ?> selected  <?php endif; ?>>4 hitos</option>
                            <option value='5' <?php if(session('seleccionado')=='5'): ?> selected  <?php endif; ?>>5 hitos</option>
                                                                
                            </select>
                                
                           
                        </div>
                    
                        <div class="form-group mr-sm-2">
                            <a id='hitosexcel' class="btn btn-sm btn-primary" title="Descargar EXCEL"><i class="fas fa-file-excel"></i></a>
                        </div>
               
                </form>  
       </div>  
</nav>
     <br>    

    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-12">
             <legend class="w-auto">Listado de proyectos</legend>        
               
       
                <div class="col-md-12">
                <div class="table-responsive">
          
                 <table class="table table-hover table-bordered" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <div style="col-md-2"><th scope="col">Nombre</th></div>
                        <div style="col-md-2"><th scope="col">Provincia</th></div>
                        <div style="col-md-2"><th scope="col">Término municipal</th></div>
                        <div style="col-md-1"><th scope="col">Sociedad</th></div>
                        <div style="col-md-1"><th scope="col">Dado de alta</th></div>
                        <div style="col-md-1"><th scope="col">Tot / Fin</th></div>
                        <div style="col-md-1"><th scope="col">Hitos</th></div>
                        <div style="col-md-2"><th scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php if($proyectos): ?>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div style="col-md-2"><td><a href="/proyecto/<?php echo e($proyecto->id); ?>/ver"><?php echo e($proyecto->nom_proyecto); ?></a></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->provincia); ?></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div style="col-md-1"><td><?php echo e($proyecto->sociedad); ?></td></div>
                        <div style="col-md-1"><td><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td></div>
                        <div style="col-md-1"><td><?php echo e($proyecto->tot); ?> / <?php echo e($proyecto->fin); ?></td></div>
                        <div style="col-md-1"><td><?php echo e($proyecto->hitos); ?></td></div>
                        <div style="col-md-2"><td>
                            
                          <a href="/proyecto/<?php echo e($proyecto->id); ?>/excel" class="btn btn-sm btn-primary" title="Descargar EXCEL del proyecto"><i class="fas fa-file-excel"></i></a>
                          
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                                                        
                           
                            
                        </td></div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?> 
                           
                </tbody>
                    
              
            </table>
                    </div>
            </div>
            
        <?php if((!is_null($proyectos)) 
        and ($proyectos->count()==0) 
        and ((session('seleccionado')=='0') or (session('seleccionado')=='1') or (session('seleccionado')=='2')
        or (session('seleccionado')=='3') or (session('seleccionado')=='4') or (session('seleccionado')=='5'))): ?>
             
        <div class="row justify-content-center align-items-center">
            <h5>No hay proyectos activos que tengan <?php echo e(session('seleccionado')); ?> hitos</h5>
        </div>    
        <?php endif; ?>
    
            
                  
        </fieldset>    
        
     
        
</div>

<?php if($proyectos): ?>
<?php echo e($proyectos->withQueryString()->links()); ?>

<?php endif; ?>

                  
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/listados.js"></script>
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views/proyectos/hitos.blade.php ENDPATH**/ ?>