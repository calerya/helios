


<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>
    
    <div class="card border-primary mb-1">
        <div class="card-body">
            <div class="col-md-12">
            <div class="card-header row justify-content-center">
                <h4 class="col-9 text-center">Mostrando finca del proyecto <strong><?php echo e($proyecto->nom_proyecto); ?></strong></h4>
                <div class="col-3 justify-content-center align-items-center float-right">
                    <button class="btn btn-primary mr-2" title="Editar finca"><i class="fas fa-edit"></i></button>
                    <a href="<?php echo e(URL::previous()); ?>" class="btn btn-primary ml-2" title="Volver atrás sin guardar datos">
                        <i class="fas fa-reply"></i>
                    </a>
                </div>
            </div>
            <div class="table-responsive form-group">
                <table class="table table-hover table-bordered" style="text-align:center;">
                    <tr class="table-active">
                        <th width="20%" scope="col">Ref Catastral</th>
                        <th scope="col">Provincia</th>
                        <th scope="col">Municipio</th>
                        <th scope="col">Zona</th>
                        <th width="9%" scope="col">Polígono</th>
                        <th width="9%" scope="col">Parcela</th>
                        <th width="9%" scope="col">Uso</th>
                    </tr>
                    
                    <tr>
                        <td width="20%"><?php echo e($finca->ref_catastral); ?></td>
                        <td><?php echo e($finca->provincia); ?></td>
                        <td><?php echo e($finca->municipio); ?></td>
                        <td><?php echo e($finca->zona); ?></td>
                        <td width="9%"><?php echo e($finca->poligono); ?></td>
                        <td width="9%"><?php echo e($finca->parcela); ?></td>
                        <td width="9%"><?php echo e($finca->uso); ?></td>
                    </tr>

                    <tr  class="table-active">
                        <th scope="col">Venta / Alq</th>
                        <th scope="col">Sup. Cat. ha</th>
                        <th scope="col">Sup. Útil ha</th>
                    </tr>
                    <br>
                    <tr>
                        <td><?php echo e($finca->venta_alq); ?></td>
                        <td><?php echo e($finca->sup_catastral_ha); ?></td>
                        <td><?php echo e($finca->sup_util_ha); ?></td>
                    </tr>
                </table>
            
                <div class="card border-light mb-1">
                    <div class="card-body">
                        <div class="card-title">
                            <strong>Observaciones:</strong>
                        </div>
                    </div>
                    <div class="col-md-12 mt-2" style="text-align:left;">
                        <?php echo $finca->observaciones; ?>

                    </div>
                
              
                </div>
               
              
            </div>
        </div>
    </div>
    </div>
            
                <input
                    id="proyecto_id"
                    name="proyecto_id"
                    value=<?php echo e($proyecto->id); ?>

                    type="hidden"
                >
            <br>
            
            
    
                     
  <?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HeliosV1\resources\views/fincas/show.blade.php ENDPATH**/ ?>