

<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('finalizado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('finalizado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
                
                <div class="card-header text-md-center">
                    <h5>Recuperar proyectos eliminados</h5>
                </div>
                
                            
                <table class="table table-hover" style="text-align:center;">
               
                <thead>
                    <tr class="table-primary">
                        <div><th width="20%" scope="col">Nombre</th></div>
                        <div><th width="10%" scope="col">Provincia</th></div>
                        <div><th width="20%"scope="col">Término municipal</th></div>
                        <div><th width="17%" scope="col">Sociedad</th></div>
                        <div><th width="6%" scope="col">Eliminado</th></div>
                        <div><th width="6%" scope="col">Hitos</th></div>
                        <div><th width="10%" scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div><td width="20%"><a href="/proyecto/<?php echo e($proyecto->id); ?>/ver"><?php echo e($proyecto->nom_proyecto); ?></a></td></div>
                        <div><td width="10%"><?php echo e($proyecto->provincia); ?></td></div>
                        <div><td width="20%"><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div><td width="17%"><?php echo e($proyecto->sociedad); ?></td></div>
                        <div><td width="6%"><?php echo e($proyecto->deleted_at->format('d/m/Y')); ?></td></div>
                        <div><td width="6%"><?php echo e($proyecto->hitos); ?></td></div>
                        <div><td width="10%">
                                                                               
                            <a href="/recuperar/<?php echo e($proyecto->id); ?>/proyectos" class="btn btn-sm btn-success" title="Recuperar el proyecto">
                                <i class="fas fa-upload"></i>
                            </a></td></div>
                         
                      
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       
                </tbody>
                
                
            </table>  
                        
                        
                    
                </div>
                    
     <?php echo e($proyectos->links()); ?>


<?php $__env->stopSection(); ?>


  


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Helios\resources\views/admin/users/eliminados/proyectos.blade.php ENDPATH**/ ?>