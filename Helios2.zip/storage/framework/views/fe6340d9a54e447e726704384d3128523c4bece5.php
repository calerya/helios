<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-dismissible alert-success">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('eliminado')): ?>
        <div class="alert alert-dismissible alert-warning">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('eliminado')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('cancelado')): ?>
        <div class="alert alert-dismissible alert-info">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong>Info: </strong><?php echo e(session('cancelado')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      
        <a class="navbar-brand" href="#">Buscar proyectos</a>
      
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarColor03">
               
            <?php echo e(Form::open(['route' => 'buscar', 'method' => 'GET', 'class' => 'form-inline  float-right' ])); ?>

          
             <div class="navbar-nav">
                 <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('nom_proyecto',null,['class' => 'form-control','placeholder' => 'Nombre proyecto'])); ?>

                </div>
                <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('provincia',null,['class' => 'form-control','placeholder' => 'Provincia'])); ?>

                </div>
                <div class="form-group mr-sm-2">
                    <?php echo e(Form::text('term_municipal',null,['class' => 'form-control','placeholder' => 'Término municipal'])); ?>

                </div>
                            
                 <div class="form-group mr-sm-2">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">Buscar</button>
                </div>
                 
            </div>
          
            <?php echo e(Form::close()); ?>

            
           
      </div>
    </nav>

     <br>    

    <div class="row justify-content-center align-items-center">
        <fieldset class="border p-2  col-md-12">
             <legend class="w-auto">Listado de proyectos</legend>        
               
       
                <table class="table table-hover-2" style="text-align:center;">
            
            
                <thead>
                    <tr class="table-primary">
                        <div style="col-md-2"><th scope="col">Nombre</th></div>
                        <div style="col-md-2"><th scope="col">Provincia</th></div>
                        <div style="col-md-2"><th scope="col">Término municipal</th></div>
                        <div style="col-md-2"><th scope="col">Sociedad</th></div>
                        <div style="col-md-2"><th scope="col">Dado de alta</th></div>
                        <div style="col-md-2"><th scope="col">Opciones</th></div>
                    </tr>
                </thead>
                
                
                <tbody>
                    <?php $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <div style="col-md-2"><td><?php echo e($proyecto->nom_proyecto); ?></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->provincia); ?></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->term_municipal); ?></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->sociedad); ?></td></div>
                        <div style="col-md-2"><td><?php echo e($proyecto->created_at->format('d/m/Y')); ?></td></div>
                        <div style="col-md-2"><td>
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/ver" class="btn btn-sm btn-primary" title="Ver">
                                <i class="far fa-eye"></i>
                            </a>
                            
                
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/excel" class="btn btn-sm btn-primary" title="Descargar EXCEL del proyecto"><i class="fas fa-file-excel"></i></a>
                          
                            
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>" class="btn btn-sm btn-primary" title="Editar">
                                <i class="far fa-edit"></i>
                            </a>
                            
                            <a href='/organismo/<?php echo e($proyecto->id); ?>/ver' class="btn btn-sm btn-primary" title="Añadir organismo" id="boton-alta-oproyectorg" >
                                <i class="fas fa-plus-square"></i>
                            </a>
                            
                                                        
                            <a href="/proyecto/<?php echo e($proyecto->id); ?>/eliminar" class="btn btn-sm btn-danger" title="Dar de baja" onclick="return confirm('Eliminar el proyecto y sus organismos?')">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td></div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                           
                </tbody>
                    
                   
                   <?php echo e($proyectos->render()); ?>      
            </table>
            
            
                  
        </fieldset>    
        
     
        
</div>

                  
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="/js/admin/proyectos/proy_buscador.js"></script>
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/iqlicedk/Helios/resources/views/proyectos/buscador.blade.php ENDPATH**/ ?>