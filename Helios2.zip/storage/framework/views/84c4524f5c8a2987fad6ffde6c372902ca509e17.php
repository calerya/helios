<?php $__env->startSection('content'); ?>

    <?php if(session('status')): ?>
    <div class="alert alert-success">
        <?php echo e(session('status')); ?>

    </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-dismissible alert-danger">
            
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            
        </div>
    <?php endif; ?>

    <div class="card border-primary mb-3">
        
             
        
        <form action="" method="post">    

            <?php echo e(csrf_field()); ?>

        
                                                                                       
             <div class="card-header text-md-center">
                    <h5>Añadiendo organismo a proyecto</h5>
            </div>   
                   
                        
            <input  id="proyecto-id" name="proyecto-id" type="hidden" class="form-control" value="<?php echo e($proyecto->id); ?>">
                                                                                      
            <div class="card-body">

                <table class="table table-hover" style="text-align:center;">
                    <tr>
                        <th scope="col">Organismo</th>
                        <th scope="col">Expediente</th>
                        <th scope="col">Presentación</th>
                        <th scope="col">Requerimiento</th>
                        <th scope="col">Cont. Requerimiento</th>
                        <th scope="col">Inf. pública</th>

                    </tr>

                    <tr>
                        <td><input title="Escribe para cambiar el organismo" id="organismo" type="text" class="form-control text-md-center" name="organismo" value="<?php echo e(old('organismo')); ?>" required autocomplete="organismo" autofocus>
                        </td>

                        <td><input title="Escribe para cambiar el número de expediente" id="num-expediente" type="text" class="form-control text-md-center" name="num-expediente" value="<?php echo e(old('num_expediente')); ?>">
                        </td>

                        <td><input title="Elija fecha" id="fec-presentacion" type="date" class="form-control text-md-center" name="fec-presentacion" value="<?php echo e(old('fec_presentacion')); ?>">
                        </td>

                        <td><input title="Elija fecha" id="fec-requerimiento" type="date" class="form-control text-md-center" name="fec-requerimiento" value="<?php echo e(old('fec_requerimiento')); ?>">
                        </td>


                        <td><div id="fec_cont_requerimiento">-</div></td>
                        <td><div id="fec-inicio-ip">-</div></td>



                    </tr>

                    <tr>
                        <th scope="col">Fin inf. pública</th>
                        <th scope="col">Resolución</th>
                        <th scope="col">Publicación res.</th>
                        <th scope="col">Caducidad</th>
                        <th scope="col">Solicitud prórroga</th>
                        <th scope="col">Concesión prórroga</th>
                        <th scope="col">Nº prórrogas</th>
                        
                    </tr>
                    <tr>
                        <td><div id="fec-fin-ip">-</div></td>
                        <td><div id="fec-resolucion">-</div></td>
                        <td><div id="fec-publ-resolucion">-</div></td>
                        <td><div id="fec-caducidad">-</div></td>
                        <td><div id="fec-solic-prorroga">-</div></td>
                        <td><div id="fec-concesion-pror">-</div></td>
                    </tr>
                    
                    <tr>
                        <th scope="col">Nº prórrogas</th>
                    </tr>
                    
                    <tr>
                        <td><div id="num-prorrogas">-</div></td>
                    </tr>
        </table>


                
              <div class="row">
                <div class="col-md-2" style="text-align:center;"><strong>Observaciones: </strong></div>
                <div class="col-md-10" style="text-align:left;" id="observaciones">-</div>
             </div>     

         </div>

            <div class="text-md-center">
                <button class="btn btn-primary" title="Alta de Organismo">
                    <i class="fas fa-save"></i></button>

                <button type="reset" class="btn btn-danger" title="Cancelar edición"><i class="fas fa-times"></i></button>

                <a href="/proyectos" class="btn btn-primary" title="Volver sin guardar">
                <i class="fas fa-reply"></i>
                </a>
            </div>


        </form>
            
        
                        
                    
    </div>
                    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Helios/resources/views//organismos/index.blade.php ENDPATH**/ ?>