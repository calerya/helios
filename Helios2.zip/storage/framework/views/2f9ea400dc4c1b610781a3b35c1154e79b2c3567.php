
 

    
   <style>
        header { background:#99CCCC; color:#FFFFFF; padding:15px; }
        footer { position: fixed; bottom: -60px; left: 0px; right: 0px; background-color: lightblue; height: 50px; }
        p { page-break-after: always; }
        p:last-child { page-break-after: never; }
       
        body {font-family: Arial, Helvetica, sans-serif;}

        table {font-family: "Lucida Sans Unicode", "Lucida Grande", Sans-Serif;
                font-size: 13px; margin 25px; width: 100%; text-align:center;border-collapse: collapse; }

        th {font-size: 13px;font-weight: normal;padding: 8px;text-align:center;background: #b9c9fe;
            border-top: 5px solid #aabcfe;border-bottom: 1px solid #fff; color: #039; }

        td {padding: 8px;background: #e8edff;text-align:center;border-bottom: 1px solid #fff;
            color: #669;border-top: 1px solid transparent; }

        tr:hover td { background: #d0dafd; color: #339; }
    </style>
  

    
<body>
    


            <table class="table" style="text-align:center">
            
            
                <thead>
                    <tr>
                        <th scope="col">Proyecto</th>
                        <th scope="col">Provincia</th>
                        <th scope="col">Municipio</th>
                        <th scope="col">Sociedad</th>
                        <th scope="col">Organismo</th>
                        <th scope="col">Expediente</th>
                        <th scope="col">Presentación</th>
                        <th scope="col">Requerim.</th>
                        <th scope="col">Contestación</th>
                        <th scope="col">Inicio IP</th>
                        <th scope="col">Fin IP</th>
                        <th scope="col">Resolución</th>
                        <th scope="col">Publicación</th>
                        <th scope="col">Caducidad</th>
                        <th scope="col">Solicitud pr</th>
                        <th scope="col">Concesión pr</th>
                        <th scope="col">Observaciones</th>
                        
                    </tr>
                </thead>
                
                
                
                <tbody>
                    <?php $__currentLoopData = $organismos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organismo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($organismo->nombre); ?></td>
                        <td><?php echo e($organismo->provincia); ?></td>
                        <td><?php echo e($organismo->municipio); ?></td>
                        <td><?php echo e($organismo->sociedad); ?></td>
                        <td><?php echo e($organismo->organismo); ?></td>
                        <td><?php echo e($organismo->num_expediente); ?></td>
                        <td><?php if($organismo->fec_presentacion): ?><?php echo e($organismo->fec_presentacion->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_requerimiento): ?><?php echo e($organismo->fec_requerimiento->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_cont_requerimiento): ?><?php echo e($organismo->fec_cont_requerimiento->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_inicio_ip): ?><?php echo e($organismo->fec_inicio_ip->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_fin_ip): ?><?php echo e($organismo->fec_fin_ip->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_resolucion): ?><?php echo e($organismo->fec_resolucion->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_publicacion): ?><?php echo e($organismo->fec_publicacion->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_caducidad): ?><?php echo e($organismo->fec_caducidad->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_solic_prorroga): ?><?php echo e($organismo->fec_solic_prorroga->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php if($organismo->fec_concesion_pror): ?><?php echo e($organismo->fec_concesion_pror->format('d/m/Y')); ?> <?php endif; ?></td>
                        <td><?php echo e($organismo->observaciones); ?></td>

                       
                       
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                           
                </tbody>
                    
            </table>
    
   
    <?php if(!is_null($organismos)): ?>
        <?php if($organismos->count()==0): ?>
      
        <div style="text-align:center">
            <h5>No hay registros que cumplan con el criterio seleccionado</h5>
        </div>  
    
    <?php endif; ?>
    <?php endif; ?>
    
    
               
      
</body>

</html>
 <?php /**PATH /home/iqlicedk/Helios/resources/views/EXCEL/organismos.blade.php ENDPATH**/ ?>